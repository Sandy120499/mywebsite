import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Phone, Mail, Facebook, Instagram, Linkedin, Twitter, GraduationCap } from 'lucide-react';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Courses', path: '/courses' },
    { name: 'About Us', path: '/about' },
    { name: 'Gallery', path: '/gallery' },
    { name: 'Contact Us', path: '/contact' },
  ];

  return (
    <header className={`fixed w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-white shadow-lg' : 'bg-transparent'}`}>
      {/* Top Bar */}
      <div className={`${isScrolled ? 'hidden' : 'block'} bg-primary text-white py-2 transition-all duration-300`}>
        <div className="container mx-auto px-4 flex justify-between items-center text-sm">
          <div className="flex items-center space-x-6">
            <div className="flex items-center space-x-2">
              <Phone size={14} />
              <span>+91 98765 43210</span>
            </div>
            <div className="flex items-center space-x-2">
              <Mail size={14} />
              <span>info@empeehotel.edu</span>
            </div>
          </div>
          <div className="hidden md:flex items-center space-x-4">
            <a href="#" className="hover:text-accent transition-colors">
              <Facebook size={16} />
            </a>
            <a href="#" className="hover:text-accent transition-colors">
              <Instagram size={16} />
            </a>
            <a href="#" className="hover:text-accent transition-colors">
              <Linkedin size={16} />
            </a>
            <a href="#" className="hover:text-accent transition-colors">
              <Twitter size={16} />
            </a>
          </div>
        </div>
      </div>

      {/* Main Navigation */}
      <nav className="py-4 bg-white bg-opacity-95 backdrop-blur-sm">
        <div className="container mx-auto px-4 flex justify-between items-center">
          {/* Logo */}
          <Link to="/" className="flex items-center space-x-3">
            <div className="w-12 h-12 bg-accent rounded-full flex items-center justify-center">
              <GraduationCap className="text-white" size={24} />
            </div>
            <div>
              <h1 className="text-xl font-bold text-primary">
                Empee Institute
              </h1>
              <p className="text-sm text-secondary">
                Hotel Management
              </p>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <Link
                key={link.name}
                to={link.path}
                className={`font-medium transition-all duration-300 relative group ${
                  location.pathname === link.path
                    ? 'text-accent'
                    : 'text-primary hover:text-accent'
                }`}
              >
                {link.name}
                <span className="absolute bottom-0 left-0 w-0 h-0.5 bg-accent transition-all duration-300 group-hover:w-full"></span>
              </Link>
            ))}
          </div>

          {/* Mobile Menu Toggle */}
          <button
            className="md:hidden p-2 text-primary"
            onClick={toggleMenu}
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden bg-white shadow-lg border-t">
            <div className="container mx-auto px-4 py-4 space-y-4">
              {navLinks.map((link) => (
                <Link
                  key={link.name}
                  to={link.path}
                  className={`block py-2 font-medium transition-colors ${
                    location.pathname === link.path
                      ? 'text-accent'
                      : 'text-primary hover:text-accent'
                  }`}
                  onClick={() => setIsMenuOpen(false)}
                >
                  {link.name}
                </Link>
              ))}
              
              {/* Mobile Social Links */}
              <div className="flex items-center space-x-4 pt-4 border-t">
                <a href="#" className="text-primary hover:text-accent transition-colors">
                  <Facebook size={20} />
                </a>
                <a href="#" className="text-primary hover:text-accent transition-colors">
                  <Instagram size={20} />
                </a>
                <a href="#" className="text-primary hover:text-accent transition-colors">
                  <Linkedin size={20} />
                </a>
                <a href="#" className="text-primary hover:text-accent transition-colors">
                  <Twitter size={20} />
                </a>
              </div>
              
              {/* Mobile Contact Info */}
              <div className="pt-4 border-t text-sm text-gray-600">
                <div className="flex items-center space-x-2 mb-2">
                  <Phone size={14} />
                  <span>+91 98765 43210</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Mail size={14} />
                  <span>info@empeehotel.edu</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
};

export default Header;