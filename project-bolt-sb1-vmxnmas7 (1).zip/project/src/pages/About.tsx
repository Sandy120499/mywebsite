import React, { useState } from 'react';
import { Target, Eye, Users, Award, BookOpen, Globe, Calendar, CheckCircle } from 'lucide-react';
import AnimatedSection from '../components/AnimatedSection';
import { useStaggeredAnimation } from '../hooks/useScrollAnimation';

const About: React.FC = () => {
  const [activeTimelineItem, setActiveTimelineItem] = useState(0);
  const { ref: achievementsRef, visibleItems: achievementsVisible } = useStaggeredAnimation(4, 0.2);
  const { ref: partnersRef, visibleItems: partnersVisible } = useStaggeredAnimation(8, 0.1);

  const timelineEvents = [
    {
      year: "2000",
      title: "Foundation",
      description: "Empee Institute established with a vision to provide quality hospitality education."
    },
    {
      year: "2005",
      title: "First Graduates",
      description: "Our first batch of 50 students graduated with 100% placement record."
    },
    {
      year: "2010",
      title: "Campus Expansion",
      description: "New state-of-the-art facilities including modern kitchens and training restaurants."
    },
    {
      year: "2015",
      title: "International Recognition",
      description: "Received accreditation from International Hotel Management Institute, Switzerland."
    },
    {
      year: "2020",
      title: "Digital Innovation",
      description: "Launched online learning platform and virtual reality training modules."
    },
    {
      year: "2024",
      title: "Excellence Milestone",
      description: "Celebrating 24 years of excellence with over 5000 successful graduates."
    }
  ];

  const achievements = [
    { number: "5000+", label: "Graduates", icon: <Users className="text-accent" size={24} /> },
    { number: "95%", label: "Placement Rate", icon: <Award className="text-accent" size={24} /> },
    { number: "200+", label: "Industry Partners", icon: <Globe className="text-accent" size={24} /> },
    { number: "24", label: "Years of Excellence", icon: <Calendar className="text-accent" size={24} /> }
  ];

  const partners = [
    "Marriott International", "Hilton Hotels", "Taj Hotels", "ITC Hotels", 
    "Oberoi Group", "Hyatt Hotels", "Radisson Hotel Group", "AccorHotels"
  ];

  return (
    <div className="min-h-screen pt-32">
      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-to-r from-primary to-secondary text-white overflow-hidden">
        <div className="container">
          <div className="max-w-4xl mx-auto text-center">
            <AnimatedSection animation="slideUp" duration={1}>
              <h1 className="text-4xl md:text-5xl font-bold mb-6">About Empee Institute</h1>
            </AnimatedSection>
            <AnimatedSection animation="slideUp" delay={0.3} duration={1}>
              <p className="text-xl md:text-2xl mb-8">
                Pioneering excellence in hospitality education for over two decades
              </p>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Vision & Mission */}
      <section className="section bg-light-gray">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <AnimatedSection animation="slideRight" duration={0.8}>
              <div className="card p-8 text-center h-full">
                <div className="flex justify-center mb-6">
                  <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center">
                    <Eye className="text-white" size={32} />
                  </div>
                </div>
                <h3 className="text-2xl font-bold mb-4">Our Vision</h3>
                <p className="text-gray-600 leading-relaxed">
                  To be the premier institution for hospitality education, recognized globally for our commitment to excellence, 
                  innovation, and the development of industry leaders who will shape the future of hospitality.
                </p>
              </div>
            </AnimatedSection>

            <AnimatedSection animation="slideLeft" duration={0.8} delay={0.2}>
              <div className="card p-8 text-center h-full">
                <div className="flex justify-center mb-6">
                  <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center">
                    <Target className="text-white" size={32} />
                  </div>
                </div>
                <h3 className="text-2xl font-bold mb-4">Our Mission</h3>
                <p className="text-gray-600 leading-relaxed">
                  To provide comprehensive, industry-relevant education and training that prepares students for successful careers 
                  in hospitality, while fostering innovation, ethical practices, and service excellence.
                </p>
              </div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="section">
        <div className="container">
          <AnimatedSection animation="slideUp" duration={0.8}>
            <h2 className="section-title">Our Journey</h2>
          </AnimatedSection>
          <div className="relative">
            {/* Timeline Line */}
            <div className="absolute left-1/2 transform -translate-x-1/2 w-1 bg-accent h-full hidden md:block"></div>
            
            <div className="space-y-8">
              {timelineEvents.map((event, index) => (
                <AnimatedSection 
                  key={index}
                  animation="slideUp"
                  delay={index * 0.1}
                  duration={0.6}
                >
                  <div className={`relative flex items-center ${
                    index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'
                  }`}>
                    {/* Timeline Dot */}
                    <div className="absolute left-1/2 transform -translate-x-1/2 w-6 h-6 bg-accent rounded-full border-4 border-white shadow-lg hidden md:block z-10"></div>
                    
                    {/* Content */}
                    <div className={`w-full md:w-1/2 ${index % 2 === 0 ? 'md:pr-8' : 'md:pl-8'}`}>
                      <div className="card p-6 hover:shadow-lg transition-shadow">
                        <div className="flex items-center space-x-3 mb-3">
                          <div className="w-8 h-8 bg-accent rounded-full flex items-center justify-center">
                            <span className="text-white font-bold text-sm">{event.year}</span>
                          </div>
                          <h3 className="text-xl font-semibold">{event.title}</h3>
                        </div>
                        <p className="text-gray-600">{event.description}</p>
                      </div>
                    </div>
                  </div>
                </AnimatedSection>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Chairman's Message */}
      <section className="section bg-light-gray">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <AnimatedSection animation="slideRight" duration={0.8}>
              <div>
                <img
                  src="https://images.pexels.com/photos/3778876/pexels-photo-3778876.jpeg?auto=compress&cs=tinysrgb&w=600"
                  alt="Chairman"
                  className="rounded-lg shadow-lg"
                />
              </div>
            </AnimatedSection>
            <AnimatedSection animation="slideLeft" duration={0.8} delay={0.2}>
              <div>
                <h2 className="text-3xl font-bold mb-6">Chairman's Message</h2>
                <div className="bg-white p-6 rounded-lg shadow-md">
                  <p className="text-gray-600 mb-4 italic">
                    "Over the past 24 years, we have witnessed the hospitality industry evolve dramatically. 
                    At Empee Institute, we have consistently adapted our curriculum to meet these changing needs while 
                    maintaining our commitment to excellence."
                  </p>
                  <p className="text-gray-600 mb-4">
                    "Our graduates don't just find jobs; they become leaders who drive innovation and set new standards 
                    in hospitality. We take pride in our holistic approach to education that combines theoretical knowledge 
                    with practical experience."
                  </p>
                  <div className="border-t pt-4">
                    <h4 className="font-semibold">Dr. Rajesh Sharma</h4>
                    <p className="text-sm text-gray-500">Chairman & Managing Director</p>
                  </div>
                </div>
              </div>
            </AnimatedSection>
          </div>
        </div>
      </section>

      {/* Achievements */}
      <section className="section">
        <div className="container">
          <AnimatedSection animation="slideUp" duration={0.8}>
            <h2 className="section-title">Our Achievements</h2>
          </AnimatedSection>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8" ref={achievementsRef}>
            {achievements.map((achievement, index) => (
              <div 
                key={index} 
                className={`text-center transition-all duration-700 ease-out ${
                  achievementsVisible[index] 
                    ? 'opacity-100 translate-y-0' 
                    : 'opacity-0 translate-y-8'
                }`}
              >
                <div className="flex justify-center mb-4 transform transition-transform duration-300 hover:scale-110">
                  {achievement.icon}
                </div>
                <div className="text-4xl font-bold text-accent mb-2">{achievement.number}</div>
                <div className="text-gray-600">{achievement.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Industry Partners */}
      <section className="section bg-light-gray">
        <div className="container">
          <AnimatedSection animation="slideUp" duration={0.8}>
            <h2 className="section-title">Industry Partnerships</h2>
            <p className="text-center text-gray-600 mb-12 max-w-3xl mx-auto">
              We collaborate with leading hospitality brands worldwide to provide our students with real-world experience 
              and excellent career opportunities.
            </p>
          </AnimatedSection>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8" ref={partnersRef}>
            {partners.map((partner, index) => (
              <div 
                key={index} 
                className={`text-center transition-all duration-700 ease-out ${
                  partnersVisible[index] 
                    ? 'opacity-100 translate-y-0' 
                    : 'opacity-0 translate-y-8'
                }`}
              >
                <div className="bg-white rounded-lg p-6 shadow-md hover:shadow-lg transition-shadow">
                  <div className="text-4xl mb-3">🏨</div>
                  <h4 className="font-medium text-gray-800">{partner}</h4>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Educational Roadmap */}
      <AnimatedSection animation="slideUp" duration={0.8}>
        <section className="section">
          <div className="container">
            <h2 className="section-title">Educational Roadmap</h2>
            <div className="bg-gradient-to-r from-primary to-secondary text-white rounded-lg p-8">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <AnimatedSection animation="slideUp" delay={0.1} duration={0.6}>
                  <div className="text-center">
                    <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center mx-auto mb-4">
                      <BookOpen className="text-white" size={32} />
                    </div>
                    <h3 className="text-xl font-semibold mb-3">Foundation</h3>
                    <p className="text-gray-200">
                      Strong theoretical foundation combined with practical skills development
                    </p>
                  </div>
                </AnimatedSection>
                <AnimatedSection animation="slideUp" delay={0.2} duration={0.6}>
                  <div className="text-center">
                    <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center mx-auto mb-4">
                      <Users className="text-white" size={32} />
                    </div>
                    <h3 className="text-xl font-semibold mb-3">Experience</h3>
                    <p className="text-gray-200">
                      Real-world experience through internships and industry projects
                    </p>
                  </div>
                </AnimatedSection>
                <AnimatedSection animation="slideUp" delay={0.3} duration={0.6}>
                  <div className="text-center">
                    <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center mx-auto mb-4">
                      <Award className="text-white" size={32} />
                    </div>
                    <h3 className="text-xl font-semibold mb-3">Excellence</h3>
                    <p className="text-gray-200">
                      Career placement and ongoing professional development support
                    </p>
                  </div>
                </AnimatedSection>
              </div>
            </div>
          </div>
        </section>
      </AnimatedSection>
    </div>
  );
};

export default About;