import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, GraduationCap, Phone, Mail, Facebook, Twitter, Instagram, Youtube } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navigation = [
    { name: 'Home', href: '/' },
    { name: 'Courses', href: '/courses' },
    { name: 'About Us', href: '/about' },
    { name: 'Gallery', href: '/gallery' },
    { name: 'Contact', href: '/contact' },
  ];

  const socialLinks = [
    { icon: Facebook, href: '#', color: 'hover:text-blue-600' },
    { icon: Twitter, href: '#', color: 'hover:text-blue-400' },
    { icon: Instagram, href: '#', color: 'hover:text-pink-500' },
    { icon: Youtube, href: '#', color: 'hover:text-red-500' },
  ];

  return (
    <>
      {/* Top Bar */}
      <div className="bg-navy-900 text-white py-3 px-4 text-sm border-b border-gold-500/20">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center space-x-8">
            <div className="flex items-center space-x-2 hover:text-gold-400 transition-colors">
              <Phone className="w-4 h-4" />
              <span className="font-medium">+91 98765 43210</span>
            </div>
            <div className="flex items-center space-x-2 hover:text-gold-400 transition-colors">
              <Mail className="w-4 h-4" />
              <span className="font-medium">admissions@empeeihm.edu</span>
            </div>
          </div>
          <div className="hidden md:flex items-center space-x-4">
            {socialLinks.map((social, index) => (
              <a
                key={index}
                href={social.href}
                className={`text-white ${social.color} transition-colors duration-300 hover:scale-110 transform`}
              >
                <social.icon className="w-5 h-5" />
              </a>
            ))}
          </div>
        </div>
      </div>

      {/* Main Header */}
      <header className={`sticky top-0 z-50 transition-all duration-500 ${
        isScrolled 
          ? 'bg-white/95 backdrop-blur-xl shadow-classic border-b border-cream-200' 
          : 'bg-white/90 backdrop-blur-sm'
      }`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-20">
            {/* Logo */}
            <Link to="/" className="flex items-center space-x-4 group">
              <div className="relative">
                <div className="bg-gradient-to-br from-navy-700 via-gold-500 to-navy-800 p-3 rounded-xl shadow-classic group-hover:shadow-elegant transition-all duration-300 group-hover:scale-105">
                  <GraduationCap className="w-8 h-8 text-white" />
                </div>
                <div className="absolute -inset-1 bg-gradient-to-br from-navy-700 via-gold-500 to-navy-800 rounded-xl blur opacity-20 group-hover:opacity-40 transition-opacity"></div>
              </div>
              <div>
                <h1 className="text-2xl font-bold text-navy-900 font-serif">
                  Empee Institute
                </h1>
                <p className="text-sm font-medium text-gold-600 font-serif">
                  Hotel Management
                </p>
              </div>
            </Link>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex space-x-2">
              {navigation.map((item) => (
                <Link
                  key={item.name}
                  to={item.href}
                  className={`relative px-6 py-3 text-sm font-semibold transition-all duration-300 rounded-lg font-serif ${
                    location.pathname === item.href
                      ? 'text-white bg-navy-800 shadow-classic'
                      : 'text-navy-700 hover:text-navy-900 hover:bg-cream-100'
                  }`}
                >
                  {item.name}
                  {location.pathname === item.href && (
                    <motion.div
                      className="absolute inset-0 bg-navy-800 rounded-lg -z-10"
                      layoutId="activeTab"
                    />
                  )}
                </Link>
              ))}
            </nav>

            {/* CTA Button */}
            <div className="hidden lg:block">
              <Link
                to="/contact"
                className="bg-gradient-to-r from-gold-500 to-gold-600 hover:from-gold-600 hover:to-gold-700 text-white px-6 py-3 rounded-lg font-semibold transition-all duration-300 shadow-classic hover:shadow-elegant transform hover:scale-105 font-serif"
              >
                Apply Now
              </Link>
            </div>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden p-2 rounded-lg text-navy-700 hover:text-navy-900 hover:bg-cream-100 transition-colors"
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              className="md:hidden bg-white/95 backdrop-blur-xl border-t border-cream-200"
            >
              <div className="max-w-7xl mx-auto px-4 py-6">
                <nav className="flex flex-col space-y-2">
                  {navigation.map((item) => (
                    <Link
                      key={item.name}
                      to={item.href}
                      onClick={() => setIsMenuOpen(false)}
                      className={`px-4 py-3 text-base font-semibold transition-all duration-300 rounded-lg font-serif ${
                        location.pathname === item.href
                          ? 'text-white bg-navy-800'
                          : 'text-navy-700 hover:text-navy-900 hover:bg-cream-100'
                      }`}
                    >
                      {item.name}
                    </Link>
                  ))}
                  <Link
                    to="/contact"
                    onClick={() => setIsMenuOpen(false)}
                    className="mt-4 bg-gradient-to-r from-gold-500 to-gold-600 text-white px-4 py-3 rounded-lg font-semibold text-center font-serif"
                  >
                    Apply Now
                  </Link>
                  <div className="flex justify-center space-x-4 mt-4 pt-4 border-t border-cream-200">
                    {socialLinks.map((social, index) => (
                      <a
                        key={index}
                        href={social.href}
                        className={`text-navy-700 ${social.color} transition-colors duration-300`}
                      >
                        <social.icon className="w-5 h-5" />
                      </a>
                    ))}
                  </div>
                </nav>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>
    </>
  );
};

export default Header;