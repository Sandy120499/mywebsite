import React from 'react';
import { Link } from 'react-router-dom';
import { GraduationCap, MapPin, Phone, Mail, Facebook, Twitter, Instagram, Youtube } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-navy-900 text-white relative overflow-hidden">
      <div className="absolute inset-0 bg-classic-pattern opacity-5"></div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Logo & Description */}
          <div className="space-y-6">
            <div className="flex items-center space-x-4">
              <div className="bg-gradient-to-br from-navy-600 via-gold-500 to-navy-700 p-3 rounded-xl shadow-classic">
                <GraduationCap className="w-8 h-8 text-white" />
              </div>
              <div>
                <h3 className="text-2xl font-bold text-white font-serif">
                  Empee Institute
                </h3>
                <p className="text-sm text-cream-300 font-medium font-serif">Hotel Management</p>
              </div>
            </div>
            <p className="text-sm leading-relaxed text-cream-300 font-serif">
              Leading hospitality education institution committed to excellence in training 
              future hospitality professionals with world-class standards since 1985.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="bg-navy-800 hover:bg-gold-600 p-3 rounded-lg transition-all duration-300 transform hover:scale-110 shadow-soft">
                <Facebook className="w-5 h-5 text-white" />
              </a>
              <a href="#" className="bg-navy-800 hover:bg-gold-600 p-3 rounded-lg transition-all duration-300 transform hover:scale-110 shadow-soft">
                <Twitter className="w-5 h-5 text-white" />
              </a>
              <a href="#" className="bg-navy-800 hover:bg-gold-600 p-3 rounded-lg transition-all duration-300 transform hover:scale-110 shadow-soft">
                <Instagram className="w-5 h-5 text-white" />
              </a>
              <a href="#" className="bg-navy-800 hover:bg-gold-600 p-3 rounded-lg transition-all duration-300 transform hover:scale-110 shadow-soft">
                <Youtube className="w-5 h-5 text-white" />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-bold text-white mb-6 font-serif">Quick Links</h4>
            <ul className="space-y-3">
              <li><Link to="/" className="text-cream-300 hover:text-gold-400 transition-colors duration-300 flex items-center group font-serif">
                <span className="w-2 h-2 bg-gold-500 rounded-full mr-3 group-hover:scale-125 transition-transform"></span>
                Home
              </Link></li>
              <li><Link to="/courses" className="text-cream-300 hover:text-gold-400 transition-colors duration-300 flex items-center group font-serif">
                <span className="w-2 h-2 bg-gold-500 rounded-full mr-3 group-hover:scale-125 transition-transform"></span>
                Courses
              </Link></li>
              <li><Link to="/about" className="text-cream-300 hover:text-gold-400 transition-colors duration-300 flex items-center group font-serif">
                <span className="w-2 h-2 bg-gold-500 rounded-full mr-3 group-hover:scale-125 transition-transform"></span>
                About Us
              </Link></li>
              <li><Link to="/gallery" className="text-cream-300 hover:text-gold-400 transition-colors duration-300 flex items-center group font-serif">
                <span className="w-2 h-2 bg-gold-500 rounded-full mr-3 group-hover:scale-125 transition-transform"></span>
                Gallery
              </Link></li>
              <li><Link to="/contact" className="text-cream-300 hover:text-gold-400 transition-colors duration-300 flex items-center group font-serif">
                <span className="w-2 h-2 bg-gold-500 rounded-full mr-3 group-hover:scale-125 transition-transform"></span>
                Contact
              </Link></li>
            </ul>
          </div>

          {/* Courses */}
          <div>
            <h4 className="text-lg font-bold text-white mb-6 font-serif">Popular Courses</h4>
            <ul className="space-y-3">
              <li><a href="#" className="text-cream-300 hover:text-gold-400 transition-colors duration-300 flex items-center group font-serif">
                <span className="w-2 h-2 bg-gold-500 rounded-full mr-3 group-hover:scale-125 transition-transform"></span>
                Hotel Management
              </a></li>
              <li><a href="#" className="text-cream-300 hover:text-gold-400 transition-colors duration-300 flex items-center group font-serif">
                <span className="w-2 h-2 bg-gold-500 rounded-full mr-3 group-hover:scale-125 transition-transform"></span>
                Culinary Arts
              </a></li>
              <li><a href="#" className="text-cream-300 hover:text-gold-400 transition-colors duration-300 flex items-center group font-serif">
                <span className="w-2 h-2 bg-gold-500 rounded-full mr-3 group-hover:scale-125 transition-transform"></span>
                Event Management
              </a></li>
              <li><a href="#" className="text-cream-300 hover:text-gold-400 transition-colors duration-300 flex items-center group font-serif">
                <span className="w-2 h-2 bg-gold-500 rounded-full mr-3 group-hover:scale-125 transition-transform"></span>
                Food & Beverage
              </a></li>
              <li><a href="#" className="text-cream-300 hover:text-gold-400 transition-colors duration-300 flex items-center group font-serif">
                <span className="w-2 h-2 bg-gold-500 rounded-full mr-3 group-hover:scale-125 transition-transform"></span>
                Housekeeping
              </a></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-bold text-white mb-6 font-serif">Contact Info</h4>
            <div className="space-y-4">
              <div className="flex items-start space-x-3 group">
                <div className="bg-navy-800 p-2 rounded-lg group-hover:bg-gold-600 transition-colors">
                  <MapPin className="w-5 h-5 text-white" />
                </div>
                <p className="text-cream-300 text-sm leading-relaxed font-serif">
                  123 Hospitality Boulevard,<br />
                  Education District,<br />
                  Mumbai - 400001
                </p>
              </div>
              <div className="flex items-center space-x-3 group">
                <div className="bg-navy-800 p-2 rounded-lg group-hover:bg-gold-600 transition-colors">
                  <Phone className="w-5 h-5 text-white" />
                </div>
                <p className="text-cream-300 text-sm font-serif">+91 98765 43210</p>
              </div>
              <div className="flex items-center space-x-3 group">
                <div className="bg-navy-800 p-2 rounded-lg group-hover:bg-gold-600 transition-colors">
                  <Mail className="w-5 h-5 text-white" />
                </div>
                <p className="text-cream-300 text-sm font-serif">admissions@empeeihm.edu</p>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-navy-700 mt-12 pt-8 text-center">
          <p className="text-cream-400 text-sm font-serif">
            © {currentYear} Empee Institute of Hotel Management. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;