import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Filter, Globe } from 'lucide-react';

const Gallery = () => {
  const [activeFilter, setActiveFilter] = useState('All');
  const [selectedImage, setSelectedImage] = useState(null);

  const filters = ['All', 'Campus', 'Culinary', 'Events', 'Students', 'Facilities', 'International'];

  const images = [
    {
      id: 1,
      src: 'https://images.pexels.com/photos/3616956/pexels-photo-3616956.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
      category: 'Culinary',
      title: 'International Culinary Lab',
      description: 'World-class kitchen facilities with latest European equipment for international cuisine training'
    },
    {
      id: 2,
      src: 'https://images.pexels.com/photos/271639/pexels-photo-271639.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
      category: 'Campus',
      title: 'Global Campus Entrance',
      description: 'Main entrance to our internationally recognized campus'
    },
    {
      id: 3,
      src: 'https://images.pexels.com/photos/3184183/pexels-photo-3184183.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
      category: 'Students',
      title: 'International Student Learning',
      description: 'Students from diverse backgrounds engaged in global hospitality training'
    },
    {
      id: 4,
      src: 'https://images.pexels.com/photos/3662120/pexels-photo-3662120.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
      category: 'Culinary',
      title: 'Global Culinary Arts Workshop',
      description: 'Students practicing international culinary techniques and molecular gastronomy'
    },
    {
      id: 5,
      src: 'https://images.pexels.com/photos/1190298/pexels-photo-1190298.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
      category: 'Events',
      title: 'International Cultural Event',
      description: 'Students organizing multicultural hospitality events with global themes'
    },
    {
      id: 6,
      src: 'https://images.pexels.com/photos/3184194/pexels-photo-3184194.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
      category: 'Facilities',
      title: 'International Resource Library',
      description: 'Well-equipped library with global hospitality resources and digital access'
    },
    {
      id: 7,
      src: 'https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
      category: 'Students',
      title: 'Global Study Groups',
      description: 'International students collaborating on hospitality projects'
    },
    {
      id: 8,
      src: 'https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
      category: 'Campus',
      title: 'International Campus Courtyard',
      description: 'Beautiful outdoor spaces designed for multicultural interactions'
    },
    {
      id: 9,
      src: 'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
      category: 'Culinary',
      title: 'Professional International Kitchen',
      description: 'Industrial-grade kitchen equipment meeting global standards'
    },
    {
      id: 10,
      src: 'https://images.pexels.com/photos/3184432/pexels-photo-3184432.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
      category: 'Events',
      title: 'International Graduation Ceremony',
      description: 'Celebrating student achievements with global recognition'
    },
    {
      id: 11,
      src: 'https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
      category: 'Facilities',
      title: 'Global Technology Lab',
      description: 'Modern computer lab with international hospitality software'
    },
    {
      id: 12,
      src: 'https://images.pexels.com/photos/1549196/pexels-photo-1549196.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
      category: 'Campus',
      title: 'International Campus Building',
      description: 'Modern architecture reflecting global design standards'
    },
    {
      id: 13,
      src: 'https://images.pexels.com/photos/3184183/pexels-photo-3184183.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
      category: 'International',
      title: 'Global Exchange Program',
      description: 'Students participating in international exchange programs'
    },
    {
      id: 14,
      src: 'https://images.pexels.com/photos/3616956/pexels-photo-3616956.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
      category: 'International',
      title: 'International Chef Training',
      description: 'Training with renowned international chefs and culinary experts'
    },
    {
      id: 15,
      src: 'https://images.pexels.com/photos/271639/pexels-photo-271639.jpeg?auto=compress&cs=tinysrgb&w=600&h=400&fit=crop',
      category: 'International',
      title: 'Global Industry Partnerships',
      description: 'Collaborations with leading international hospitality brands'
    }
  ];

  const filteredImages = activeFilter === 'All' 
    ? images 
    : images.filter(image => image.category === activeFilter);

  const getGridClass = (index) => {
    const patterns = [
      'row-span-1',
      'row-span-2',
      'row-span-1',
      'row-span-2',
      'row-span-1',
      'row-span-1'
    ];
    return patterns[index % patterns.length];
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen pt-32 pb-20"
    >
      {/* Header */}
      <section className="bg-navy-900 text-white py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-hero-pattern opacity-10"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <motion.h1
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8 }}
            className="text-5xl md:text-6xl font-bold mb-8"
          >
            International <span className="text-gold-400">Campus Gallery</span>
          </motion.h1>
          <motion.p
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-xl text-platinum-200 max-w-4xl mx-auto leading-relaxed"
          >
            Explore our vibrant global campus life, world-class facilities, and memorable international moments
          </motion.p>
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="flex items-center justify-center mt-6"
          >
            <Globe className="w-6 h-6 text-gold-400 mr-2" />
            <span className="text-gold-400 font-semibold">International Standards & Global Recognition</span>
          </motion.div>
        </div>
      </section>

      {/* Filter Bar */}
      <section className="py-12 bg-white border-b border-platinum-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap justify-center items-center gap-4">
            <div className="flex items-center bg-gradient-to-r from-navy-600 to-navy-700 text-white px-4 py-2 rounded-lg font-semibold">
              <Filter className="w-5 h-5 mr-2" />
              Filter by:
            </div>
            {filters.map((filter) => (
              <button
                key={filter}
                onClick={() => setActiveFilter(filter)}
                className={`px-6 py-3 rounded-lg font-semibold transition-all duration-300 transform hover:scale-105 ${
                  activeFilter === filter
                    ? 'bg-gradient-to-r from-navy-600 to-navy-700 text-white shadow-premium'
                    : 'bg-white text-navy-700 hover:text-navy-900 hover:bg-platinum-100 shadow-elegant border border-platinum-200'
                }`}
              >
                {filter === 'International' && <Globe className="w-4 h-4 mr-2 inline" />}
                {filter}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* Gallery Grid */}
      <section className="py-16 bg-gradient-to-br from-platinum-50 to-navy-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 auto-rows-min">
            <AnimatePresence>
              {filteredImages.map((image, index) => (
                <motion.div
                  key={image.id}
                  layout
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.8 }}
                  transition={{ duration: 0.4 }}
                  className={`group relative overflow-hidden rounded-xl shadow-premium hover:shadow-luxury transition-all duration-300 cursor-pointer transform hover:scale-105 ${getGridClass(index)}`}
                  onClick={() => setSelectedImage(image)}
                >
                  <img
                    src={image.src}
                    alt={image.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-navy-900/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                      <h3 className="text-lg font-bold mb-2">{image.title}</h3>
                      <p className="text-sm text-platinum-200">{image.description}</p>
                    </div>
                  </div>
                  <div className="absolute top-4 right-4 bg-gradient-to-r from-navy-600 to-navy-700 text-white px-3 py-1 rounded-lg text-sm font-semibold opacity-0 group-hover:opacity-100 transition-opacity shadow-elegant">
                    {image.category}
                  </div>
                  {image.category === 'International' && (
                    <div className="absolute top-4 left-4 bg-gold-500 text-white px-3 py-1 rounded-lg text-xs font-semibold flex items-center">
                      <Globe className="w-3 h-3 mr-1" />
                      Global
                    </div>
                  )}
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </div>
      </section>

      {/* Lightbox */}
      <AnimatePresence>
        {selectedImage && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4"
            onClick={() => setSelectedImage(null)}
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              transition={{ type: 'spring', damping: 25, stiffness: 300 }}
              className="relative max-w-5xl max-h-full bg-white rounded-xl overflow-hidden shadow-luxury"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                onClick={() => setSelectedImage(null)}
                className="absolute top-6 right-6 z-10 bg-black/50 hover:bg-black/70 text-white p-3 rounded-full transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
              
              <img
                src={selectedImage.src}
                alt={selectedImage.title}
                className="w-full h-auto max-h-[70vh] object-contain"
              />
              
              <div className="p-8 bg-white">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-3xl font-bold text-navy-900">{selectedImage.title}</h3>
                  <div className="flex items-center space-x-2">
                    <span className="bg-gradient-to-r from-navy-600 to-navy-700 text-white px-4 py-2 rounded-lg text-sm font-semibold">
                      {selectedImage.category}
                    </span>
                    {selectedImage.category === 'International' && (
                      <span className="bg-gold-500 text-white px-3 py-1 rounded-lg text-xs font-semibold flex items-center">
                        <Globe className="w-3 h-3 mr-1" />
                        Global
                      </span>
                    )}
                  </div>
                </div>
                <p className="text-navy-600 leading-relaxed text-lg">{selectedImage.description}</p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Stats Section */}
      <section className="py-20 bg-navy-900 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-hero-pattern opacity-5"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
            <motion.div
              initial={{ y: 30, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.6 }}
              className="bg-white/10 backdrop-blur-lg p-8 rounded-xl border border-white/20"
            >
              <h3 className="text-4xl font-bold text-gold-400 mb-3">50+</h3>
              <p className="text-platinum-300 font-semibold">International Facilities</p>
            </motion.div>
            <motion.div
              initial={{ y: 30, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="bg-white/10 backdrop-blur-lg p-8 rounded-xl border border-white/20"
            >
              <h3 className="text-4xl font-bold text-gold-400 mb-3">25+</h3>
              <p className="text-platinum-300 font-semibold">Global Standard Labs</p>
            </motion.div>
            <motion.div
              initial={{ y: 30, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="bg-white/10 backdrop-blur-lg p-8 rounded-xl border border-white/20"
            >
              <h3 className="text-4xl font-bold text-gold-400 mb-3">1000+</h3>
              <p className="text-platinum-300 font-semibold">International Students</p>
            </motion.div>
            <motion.div
              initial={{ y: 30, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="bg-white/10 backdrop-blur-lg p-8 rounded-xl border border-white/20"
            >
              <h3 className="text-4xl font-bold text-gold-400 mb-3">100+</h3>
              <p className="text-platinum-300 font-semibold">Global Events Annually</p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-gradient-to-r from-gold-500 via-gold-600 to-gold-500 relative overflow-hidden">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="max-w-5xl mx-auto text-center px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.h2
            initial={{ y: 30, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8 }}
            className="text-4xl font-bold text-white mb-6"
          >
            Want to Experience Our International Campus?
          </motion.h2>
          <motion.p
            initial={{ y: 30, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-xl text-white mb-10 opacity-90 leading-relaxed"
          >
            Visit our globally recognized campus to experience our world-class facilities firsthand
          </motion.p>
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="flex flex-col sm:flex-row gap-6 justify-center"
          >
            <button className="bg-white text-gold-600 px-10 py-4 rounded-lg font-bold hover:bg-platinum-100 transition-all duration-300 transform hover:scale-105 shadow-luxury">
              Schedule Campus Visit
            </button>
            <button className="border-2 border-white text-white hover:bg-white hover:text-gold-600 px-10 py-4 rounded-lg font-bold transition-all duration-300 shadow-premium">
              Contact Us
            </button>
          </motion.div>
        </div>
      </section>
    </motion.div>
  );
};

export default Gallery;