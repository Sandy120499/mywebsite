import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Clock, Users, Award, DollarSign, BookOpen, CheckCircle, Globe } from 'lucide-react';

const Courses = () => {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [compareList, setCompareList] = useState([]);

  const categories = ['All', 'Undergraduate', 'Postgraduate', 'Diploma', 'Certificate'];

  const courses = [
    {
      id: 1,
      title: 'Bachelor of International Hotel Management',
      category: 'Undergraduate',
      duration: '4 Years',
      fees: '₹2,50,000',
      seats: '120',
      image: 'https://images.pexels.com/photos/271639/pexels-photo-271639.jpeg?auto=compress&cs=tinysrgb&w=400&h=250&fit=crop',
      curriculum: ['Global Hotel Operations', 'International F&B', 'Housekeeping Standards', 'Front Office Management', 'Revenue Management'],
      careers: ['International Hotel Manager', 'Resort Manager', 'Event Coordinator', 'Tourism Officer'],
      requirements: 'Class 12 with minimum 50% marks',
      highlights: ['Global Internship', 'International Exposure', 'Placement Guarantee'],
      color: 'from-navy-600 to-navy-700',
      international: true
    },
    {
      id: 2,
      title: 'Diploma in International Culinary Arts',
      category: 'Diploma',
      duration: '2 Years',
      fees: '₹1,80,000',
      seats: '60',
      image: 'https://images.pexels.com/photos/3662120/pexels-photo-3662120.jpeg?auto=compress&cs=tinysrgb&w=400&h=250&fit=crop',
      curriculum: ['Global Culinary Techniques', 'International Cuisine', 'Food Safety Standards', 'Kitchen Management', 'Molecular Gastronomy'],
      careers: ['Executive Chef', 'Sous Chef', 'Kitchen Manager', 'Food Consultant'],
      requirements: 'Class 10 with minimum 45% marks',
      highlights: ['Michelin Training', 'International Mentorship', 'Recipe Innovation'],
      color: 'from-gold-500 to-gold-600',
      international: true
    },
    {
      id: 3,
      title: 'Master of Global Hospitality Management',
      category: 'Postgraduate',
      duration: '2 Years',
      fees: '₹3,20,000',
      seats: '40',
      image: 'https://images.pexels.com/photos/3184183/pexels-photo-3184183.jpeg?auto=compress&cs=tinysrgb&w=400&h=250&fit=crop',
      curriculum: ['Strategic Management', 'Global Revenue Management', 'Digital Marketing', 'Leadership', 'International Business'],
      careers: ['General Manager', 'Operations Director', 'Business Consultant', 'Entrepreneur'],
      requirements: 'Bachelor\'s degree with minimum 55% marks',
      highlights: ['Research Projects', 'Global Collaboration', 'International Perspective'],
      color: 'from-emerald-500 to-emerald-600',
      international: true
    },
    {
      id: 4,
      title: 'Certificate in International Event Management',
      category: 'Certificate',
      duration: '6 Months',
      fees: '₹85,000',
      seats: '80',
      image: 'https://images.pexels.com/photos/1190298/pexels-photo-1190298.jpeg?auto=compress&cs=tinysrgb&w=400&h=250&fit=crop',
      curriculum: ['Global Event Planning', 'Vendor Management', 'Budget Planning', 'International Marketing', 'Cultural Events'],
      careers: ['Event Planner', 'Wedding Coordinator', 'Corporate Event Manager'],
      requirements: 'Class 12 pass',
      highlights: ['International Projects', 'Industry Connect', 'Quick Employment'],
      color: 'from-navy-500 to-gold-500',
      international: true
    },
    {
      id: 5,
      title: 'Diploma in Global Food & Beverage Service',
      category: 'Diploma',
      duration: '1 Year',
      fees: '₹1,20,000',
      seats: '50',
      image: 'https://images.pexels.com/photos/3616956/pexels-photo-3616956.jpeg?auto=compress&cs=tinysrgb&w=400&h=250&fit=crop',
      curriculum: ['International Service Techniques', 'Wine Knowledge', 'Bar Operations', 'Customer Service', 'Sommelier Training'],
      careers: ['Restaurant Manager', 'Sommelier', 'Bar Manager', 'Service Supervisor'],
      requirements: 'Class 10 with minimum 45% marks',
      highlights: ['Live Training', 'International Certification', 'Job Guarantee'],
      color: 'from-emerald-500 to-navy-600',
      international: true
    },
    {
      id: 6,
      title: 'Bachelor of Global Tourism Management',
      category: 'Undergraduate',
      duration: '3 Years',
      fees: '₹2,10,000',
      seats: '100',
      image: 'https://images.pexels.com/photos/1549196/pexels-photo-1549196.jpeg?auto=compress&cs=tinysrgb&w=400&h=250&fit=crop',
      curriculum: ['Global Tourism Geography', 'Travel Operations', 'Heritage Studies', 'Eco-Tourism', 'Digital Tourism'],
      careers: ['Travel Agent', 'Tour Guide', 'Tourism Officer', 'Adventure Tourism Manager'],
      requirements: 'Class 12 with minimum 50% marks',
      highlights: ['International Field Trips', 'Cultural Exposure', 'Language Training'],
      color: 'from-gold-500 to-navy-600',
      international: true
    }
  ];

  const filteredCourses = selectedCategory === 'All' 
    ? courses 
    : courses.filter(course => course.category === selectedCategory);

  const toggleCompare = (courseId) => {
    setCompareList(prev => 
      prev.includes(courseId) 
        ? prev.filter(id => id !== courseId)
        : prev.length < 3 ? [...prev, courseId] : prev
    );
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen pt-32 pb-20"
    >
      {/* Header */}
      <section className="bg-navy-900 text-white py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-hero-pattern opacity-10"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <motion.h1
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8 }}
            className="text-5xl md:text-6xl font-bold mb-8"
          >
            Our <span className="text-gold-400">International Courses</span>
          </motion.h1>
          <motion.p
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-xl text-platinum-200 max-w-4xl mx-auto leading-relaxed"
          >
            Comprehensive hospitality programs designed to international standards to prepare you 
            for a successful career in the global hospitality industry
          </motion.p>
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="flex items-center justify-center mt-6"
          >
            <Globe className="w-6 h-6 text-gold-400 mr-2" />
            <span className="text-gold-400 font-semibold">International Standards & Global Recognition</span>
          </motion.div>
        </div>
      </section>

      {/* Filter Categories */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-8 py-4 rounded-lg font-semibold transition-all duration-300 transform hover:scale-105 ${
                  selectedCategory === category
                    ? 'bg-gradient-to-r from-navy-600 to-navy-700 text-white shadow-premium'
                    : 'bg-white text-navy-700 hover:text-navy-900 hover:bg-platinum-100 shadow-elegant border border-platinum-200'
                }`}
              >
                {category}
              </button>
            ))}
          </div>

          {/* Compare Section */}
          {compareList.length > 0 && (
            <div className="bg-gradient-to-r from-navy-50 to-gold-50 border border-navy-200 rounded-xl p-6 mb-12 shadow-elegant">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <span className="text-navy-800 font-bold text-lg">Compare Courses:</span>
                  <span className="bg-gradient-to-r from-navy-600 to-navy-700 text-white px-4 py-2 rounded-lg font-semibold">{compareList.length} selected</span>
                </div>
                <button
                  onClick={() => setCompareList([])}
                  className="text-navy-600 hover:text-navy-800 font-semibold bg-white px-4 py-2 rounded-lg hover:bg-platinum-50 transition-colors"
                >
                  Clear All
                </button>
              </div>
            </div>
          )}

          {/* Courses Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredCourses.map((course, index) => (
              <motion.div
                key={course.id}
                initial={{ y: 50, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="bg-white rounded-xl shadow-premium overflow-hidden hover:shadow-luxury transition-all duration-300 transform hover:scale-105 border border-platinum-200"
              >
                <div className="relative overflow-hidden">
                  <img
                    src={course.image}
                    alt={course.title}
                    className="w-full h-48 object-cover transform hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-navy-900/50 to-transparent"></div>
                  <div className={`absolute top-4 right-4 bg-gradient-to-r ${course.color} text-white px-4 py-2 rounded-lg text-sm font-semibold shadow-elegant`}>
                    {course.category}
                  </div>
                  {course.international && (
                    <div className="absolute top-4 left-4 bg-gold-500 text-white px-3 py-1 rounded-lg text-xs font-semibold flex items-center">
                      <Globe className="w-3 h-3 mr-1" />
                      International
                    </div>
                  )}
                </div>
                
                <div className="p-8">
                  <h3 className="text-2xl font-bold text-navy-900 mb-6 leading-tight">{course.title}</h3>
                  
                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <div className="flex items-center text-sm text-navy-600 bg-platinum-50 p-3 rounded-lg">
                      <Clock className="w-4 h-4 mr-3 text-gold-500" />
                      <span className="font-medium">{course.duration}</span>
                    </div>
                    <div className="flex items-center text-sm text-navy-600 bg-platinum-50 p-3 rounded-lg">
                      <Users className="w-4 h-4 mr-3 text-gold-500" />
                      <span className="font-medium">{course.seats} seats</span>
                    </div>
                    <div className="flex items-center text-sm text-navy-600 bg-platinum-50 p-3 rounded-lg">
                      <DollarSign className="w-4 h-4 mr-3 text-gold-500" />
                      <span className="font-medium">{course.fees}</span>
                    </div>
                    <div className="flex items-center text-sm text-navy-600 bg-platinum-50 p-3 rounded-lg">
                      <Award className="w-4 h-4 mr-3 text-gold-500" />
                      <span className="font-medium">Certified</span>
                    </div>
                  </div>

                  <div className="mb-6">
                    <h4 className="font-bold text-navy-900 mb-3 text-lg">Key Highlights:</h4>
                    <ul className="text-sm text-navy-600 space-y-2">
                      {course.highlights.map((highlight, idx) => (
                        <li key={idx} className="flex items-center bg-gradient-to-r from-navy-50 to-gold-50 p-2 rounded-lg">
                          <CheckCircle className="w-4 h-4 text-gold-500 mr-3 flex-shrink-0" />
                          <span className="font-medium">{highlight}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="flex gap-3">
                    <button className={`flex-1 bg-gradient-to-r ${course.color} hover:shadow-elegant text-white px-6 py-3 rounded-lg font-semibold transition-all duration-300 transform hover:scale-105`}>
                      View Details
                    </button>
                    <button
                      onClick={() => toggleCompare(course.id)}
                      className={`px-6 py-3 rounded-lg font-semibold transition-all duration-300 transform hover:scale-105 ${
                        compareList.includes(course.id)
                          ? 'bg-gradient-to-r from-navy-600 to-navy-700 text-white shadow-elegant'
                          : 'bg-platinum-100 text-navy-700 hover:bg-platinum-200 border border-platinum-200'
                      }`}
                    >
                      {compareList.includes(course.id) ? 'Remove' : 'Compare'}
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Course Comparison Tool */}
      {compareList.length > 1 && (
        <section className="py-16 bg-gradient-to-br from-platinum-50 to-navy-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-4xl font-bold text-center mb-12 text-navy-900">
              Course <span className="text-gold-600">Comparison</span>
            </h2>
            <div className="overflow-x-auto">
              <table className="w-full bg-white rounded-xl shadow-luxury overflow-hidden border border-platinum-200">
                <thead>
                  <tr className="bg-gradient-to-r from-navy-600 to-navy-700 text-white">
                    <th className="px-8 py-6 text-left font-bold text-lg">Course</th>
                    {compareList.map(courseId => {
                      const course = courses.find(c => c.id === courseId);
                      return (
                        <th key={courseId} className="px-8 py-6 text-left font-bold text-lg">
                          {course.title}
                        </th>
                      );
                    })}
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b border-platinum-200">
                    <td className="px-8 py-6 font-bold text-navy-900 bg-platinum-50">Duration</td>
                    {compareList.map(courseId => {
                      const course = courses.find(c => c.id === courseId);
                      return <td key={courseId} className="px-8 py-6 font-medium">{course.duration}</td>;
                    })}
                  </tr>
                  <tr className="border-b border-platinum-200 bg-platinum-25">
                    <td className="px-8 py-6 font-bold text-navy-900 bg-platinum-50">Fees</td>
                    {compareList.map(courseId => {
                      const course = courses.find(c => c.id === courseId);
                      return <td key={courseId} className="px-8 py-6 font-medium">{course.fees}</td>;
                    })}
                  </tr>
                  <tr className="border-b border-platinum-200">
                    <td className="px-8 py-6 font-bold text-navy-900 bg-platinum-50">Requirements</td>
                    {compareList.map(courseId => {
                      const course = courses.find(c => c.id === courseId);
                      return <td key={courseId} className="px-8 py-6 font-medium">{course.requirements}</td>;
                    })}
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </section>
      )}

      {/* CTA Section */}
      <section className="py-20 bg-navy-900 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-hero-pattern opacity-5"></div>
        <div className="max-w-5xl mx-auto text-center px-4 sm:px-6 lg:px-8 relative z-10">
          <h2 className="text-4xl font-bold mb-6">Need Help Choosing the Right Course?</h2>
          <p className="text-xl text-platinum-300 mb-10 leading-relaxed">
            Our international counselors are here to help you find the perfect program for your global career goals
          </p>
          <div className="flex flex-col sm:flex-row gap-6 justify-center">
            <button className="bg-gradient-to-r from-gold-500 to-gold-600 hover:from-gold-600 hover:to-gold-700 text-white px-10 py-4 rounded-lg font-bold transition-all duration-300 transform hover:scale-105 shadow-luxury">
              Get International Counseling
            </button>
            <button className="border-2 border-white text-white hover:bg-white hover:text-navy-900 px-10 py-4 rounded-lg font-bold transition-all duration-300 shadow-premium">
              Download Brochure
            </button>
          </div>
        </div>
      </section>
    </motion.div>
  );
};

export default Courses;