import React from 'react';
import { motion } from 'framer-motion';
import { useInView } from 'react-intersection-observer';
import { Award, Users, BookOpen, MapPin, Calendar, Quote, Star, Trophy, Clock } from 'lucide-react';

const Home = () => {
  const [heroRef, heroInView] = useInView({ triggerOnce: true });
  const [statsRef, statsInView] = useInView({ triggerOnce: true });
  const [testimonialsRef, testimonialsInView] = useInView({ triggerOnce: true });

  const stats = [
    { icon: Users, value: '10,000+', label: 'Graduates Placed', color: 'from-navy-700 to-navy-800' },
    { icon: Award, value: '38+', label: 'Years of Excellence', color: 'from-gold-500 to-gold-600' },
    { icon: BookOpen, value: '25+', label: 'Specialized Programs', color: 'from-burgundy-600 to-burgundy-700' },
    { icon: MapPin, value: '500+', label: 'Industry Partners', color: 'from-navy-600 to-gold-600' },
  ];

  const testimonials = [
    {
      name: 'Priya Sharma',
      role: 'Hotel Manager, Taj Hotels',
      content: 'Empee Institute provided me with the perfect foundation for my hospitality career. The curriculum and industry exposure were exceptional.',
      rating: 5,
      image: 'https://images.pexels.com/photos/3785077/pexels-photo-3785077.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop'
    },
    {
      name: 'Rajesh Kumar',
      role: 'Executive Chef, ITC Hotels',
      content: 'The culinary program at Empee meets world-class standards. The faculty and facilities helped me develop skills that set me apart in the industry.',
      rating: 5,
      image: 'https://images.pexels.com/photos/3785079/pexels-photo-3785079.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop'
    },
    {
      name: 'Anita Patel',
      role: 'Event Manager, Oberoi Group',
      content: 'The comprehensive curriculum and real-world projects prepared me excellently for the dynamic hospitality industry.',
      rating: 5,
      image: 'https://images.pexels.com/photos/3785078/pexels-photo-3785078.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&fit=crop'
    }
  ];

  const news = [
    {
      title: 'New Culinary Excellence Center Inaugurated',
      date: 'March 15, 2024',
      excerpt: 'State-of-the-art culinary facilities with modern equipment to enhance practical learning experience.',
      image: 'https://images.pexels.com/photos/3616956/pexels-photo-3616956.jpeg?auto=compress&cs=tinysrgb&w=400&h=250&fit=crop'
    },
    {
      title: 'Industry Partnership with Leading Hotels',
      date: 'March 10, 2024',
      excerpt: 'Strengthening our placement opportunities with new partnerships across major hotel chains.',
      image: 'https://images.pexels.com/photos/271639/pexels-photo-271639.jpeg?auto=compress&cs=tinysrgb&w=400&h=250&fit=crop'
    },
    {
      title: 'Students Win National Culinary Competition',
      date: 'March 5, 2024',
      excerpt: 'Our culinary students secured top positions in the prestigious National Chef Championship.',
      image: 'https://images.pexels.com/photos/3662120/pexels-photo-3662120.jpeg?auto=compress&cs=tinysrgb&w=400&h=250&fit=crop'
    }
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen"
    >
      {/* Hero Section */}
      <section ref={heroRef} className="relative h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-navy-900/85 via-navy-800/75 to-navy-900/85 z-10" />
        <div className="absolute inset-0 bg-classic-pattern opacity-10 z-20" />
        <div 
          className="absolute inset-0 bg-cover bg-center bg-fixed transform scale-105"
          style={{
            backgroundImage: 'url(https://images.pexels.com/photos/3616956/pexels-photo-3616956.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080&fit=crop)'
          }}
        />
        
        <div className="relative z-30 text-center text-white max-w-6xl mx-auto px-4">
          <motion.h1
            initial={{ y: 50, opacity: 0 }}
            animate={heroInView ? { y: 0, opacity: 1 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-5xl md:text-7xl font-bold mb-8 leading-tight font-serif"
          >
            Excellence in 
            <span className="text-gold-400"> Hospitality</span>
            <br />Education
          </motion.h1>
          
          <motion.p
            initial={{ y: 30, opacity: 0 }}
            animate={heroInView ? { y: 0, opacity: 1 } : {}}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-xl md:text-2xl mb-12 text-cream-200 leading-relaxed max-w-4xl mx-auto font-serif"
          >
            Shaping Future Leaders in Hotel Management Since 1985
          </motion.p>
          
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            animate={heroInView ? { y: 0, opacity: 1 } : {}}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="flex flex-col sm:flex-row gap-6 justify-center"
          >
            <button className="bg-gradient-to-r from-gold-500 to-gold-600 hover:from-gold-600 hover:to-gold-700 text-white px-10 py-4 rounded-lg text-lg font-semibold transition-all duration-300 transform hover:scale-105 shadow-classic font-serif">
              Explore Programs
            </button>
            <button className="border-2 border-white/30 backdrop-blur-sm text-white hover:bg-white hover:text-navy-900 px-10 py-4 rounded-lg text-lg font-semibold transition-all duration-300 shadow-elegant font-serif">
              Learn More
            </button>
          </motion.div>
        </div>

        {/* Floating Elements */}
        <div className="absolute top-20 left-10 w-20 h-20 bg-gold-500/20 rounded-full animate-float"></div>
        <div className="absolute bottom-20 right-10 w-32 h-32 bg-navy-500/20 rounded-full animate-float" style={{ animationDelay: '2s' }}></div>
      </section>

      {/* Stats Section */}
      <section ref={statsRef} className="py-20 bg-gradient-to-br from-cream-50 to-cream-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <motion.div
                key={index}
                initial={{ y: 50, opacity: 0 }}
                animate={statsInView ? { y: 0, opacity: 1 } : {}}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="text-center p-8 bg-white rounded-xl shadow-classic hover:shadow-elegant transition-all duration-300 transform hover:scale-105 border border-cream-200"
              >
                <div className={`bg-gradient-to-r ${stat.color} w-20 h-20 rounded-xl flex items-center justify-center mx-auto mb-6 shadow-soft`}>
                  <stat.icon className="w-10 h-10 text-white" />
                </div>
                <h3 className="text-4xl font-bold text-navy-900 mb-3 font-serif">{stat.value}</h3>
                <p className="text-navy-600 font-semibold font-serif">{stat.label}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <motion.h2
                initial={{ x: -50, opacity: 0 }}
                whileInView={{ x: 0, opacity: 1 }}
                transition={{ duration: 0.8 }}
                className="text-5xl font-bold mb-8 text-navy-900 font-serif"
              >
                Leading the Way in 
                <span className="text-gold-600"> Hospitality</span> Education
              </motion.h2>
              <motion.p
                initial={{ x: -50, opacity: 0 }}
                whileInView={{ x: 0, opacity: 1 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="text-lg text-navy-700 mb-10 leading-relaxed font-serif"
              >
                For over three decades, Empee Institute has been at the forefront of hospitality education, 
                creating competent professionals who excel in hotels, restaurants, and hospitality 
                enterprises. Our comprehensive programs combine theoretical knowledge with hands-on 
                practical experience.
              </motion.p>
              <motion.div
                initial={{ x: -50, opacity: 0 }}
                whileInView={{ x: 0, opacity: 1 }}
                transition={{ duration: 0.8, delay: 0.4 }}
                className="grid grid-cols-1 sm:grid-cols-2 gap-6"
              >
                <div className="flex items-center space-x-4 p-4 bg-cream-50 rounded-xl shadow-soft">
                  <div className="bg-gradient-to-r from-navy-700 to-navy-800 p-3 rounded-lg">
                    <Trophy className="w-6 h-6 text-white" />
                  </div>
                  <span className="text-navy-700 font-semibold font-serif">Excellence</span>
                </div>
                <div className="flex items-center space-x-4 p-4 bg-cream-50 rounded-xl shadow-soft">
                  <div className="bg-gradient-to-r from-gold-500 to-gold-600 p-3 rounded-lg">
                    <Clock className="w-6 h-6 text-white" />
                  </div>
                  <span className="text-navy-700 font-semibold font-serif">Flexible Learning</span>
                </div>
                <div className="flex items-center space-x-4 p-4 bg-cream-50 rounded-xl shadow-soft">
                  <div className="bg-gradient-to-r from-burgundy-600 to-burgundy-700 p-3 rounded-lg">
                    <Award className="w-6 h-6 text-white" />
                  </div>
                  <span className="text-navy-700 font-semibold font-serif">Expert Faculty</span>
                </div>
                <div className="flex items-center space-x-4 p-4 bg-cream-50 rounded-xl shadow-soft">
                  <div className="bg-gradient-to-r from-navy-600 to-gold-600 p-3 rounded-lg">
                    <Users className="w-6 h-6 text-white" />
                  </div>
                  <span className="text-navy-700 font-semibold font-serif">Industry Network</span>
                </div>
              </motion.div>
            </div>
            <motion.div
              initial={{ x: 50, opacity: 0 }}
              whileInView={{ x: 0, opacity: 1 }}
              transition={{ duration: 0.8 }}
              className="relative"
            >
              <div className="relative overflow-hidden rounded-xl shadow-classic">
                <img
                  src="https://images.pexels.com/photos/3184183/pexels-photo-3184183.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop"
                  alt="Students learning"
                  className="w-full h-full object-cover transform hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-navy-900/50 to-transparent"></div>
              </div>
              <div className="absolute -bottom-8 -right-8 bg-gradient-to-r from-gold-500 to-gold-600 text-white p-8 rounded-xl shadow-classic">
                <h4 className="text-3xl font-bold font-serif">38+</h4>
                <p className="text-sm opacity-90 font-serif">Years of Excellence</p>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* News & Events */}
      <section className="py-20 bg-gradient-to-br from-cream-50 to-cream-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-bold mb-6 text-navy-900 font-serif">
              Latest <span className="text-gold-600">News & Events</span>
            </h2>
            <p className="text-xl text-navy-600 max-w-3xl mx-auto font-serif">
              Stay updated with the latest developments at Empee Institute
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {news.map((item, index) => (
              <motion.div
                key={index}
                initial={{ y: 50, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="bg-white rounded-xl shadow-classic overflow-hidden hover:shadow-elegant transition-all duration-300 transform hover:scale-105 border border-cream-200"
              >
                <div className="relative overflow-hidden">
                  <img
                    src={item.image}
                    alt={item.title}
                    className="w-full h-48 object-cover transform hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-navy-900/50 to-transparent"></div>
                </div>
                <div className="p-8">
                  <div className="flex items-center text-sm text-gold-600 mb-4 font-semibold font-serif">
                    <Calendar className="w-4 h-4 mr-2" />
                    {item.date}
                  </div>
                  <h3 className="text-xl font-bold text-navy-900 mb-4 leading-tight font-serif">{item.title}</h3>
                  <p className="text-navy-600 leading-relaxed font-serif">{item.excerpt}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section ref={testimonialsRef} className="py-20 bg-navy-900 relative overflow-hidden">
        <div className="absolute inset-0 bg-classic-pattern opacity-5"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-bold text-white mb-6 font-serif">What Our Alumni Say</h2>
            <p className="text-xl text-cream-300 max-w-3xl mx-auto font-serif">
              Hear from successful graduates who have built remarkable careers in hospitality
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <motion.div
                key={index}
                initial={{ y: 50, opacity: 0 }}
                animate={testimonialsInView ? { y: 0, opacity: 1 } : {}}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="bg-white/10 backdrop-blur-lg rounded-xl p-8 shadow-classic hover:shadow-elegant transition-all duration-300 transform hover:scale-105 border border-white/20"
              >
                <div className="flex items-center mb-6">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-gold-400 fill-current" />
                  ))}
                </div>
                <Quote className="w-10 h-10 text-gold-400 mb-6" />
                <p className="text-white mb-8 leading-relaxed text-lg font-serif">{testimonial.content}</p>
                <div className="flex items-center">
                  <img
                    src={testimonial.image}
                    alt={testimonial.name}
                    className="w-16 h-16 rounded-full object-cover mr-4 border-2 border-gold-400"
                  />
                  <div>
                    <h4 className="font-bold text-white text-lg font-serif">{testimonial.name}</h4>
                    <p className="text-gold-300 font-medium font-serif">{testimonial.role}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-gold-500 via-gold-600 to-gold-500 relative overflow-hidden">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="max-w-5xl mx-auto text-center px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.h2
            initial={{ y: 30, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8 }}
            className="text-5xl font-bold text-white mb-8 font-serif"
          >
            Ready to Start Your Hospitality Journey?
          </motion.h2>
          <motion.p
            initial={{ y: 30, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-xl text-white mb-10 opacity-90 leading-relaxed font-serif"
          >
            Join thousands of successful graduates who have built remarkable careers in hospitality
          </motion.p>
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="flex flex-col sm:flex-row gap-6 justify-center"
          >
            <button className="bg-white text-gold-600 px-10 py-4 rounded-lg text-lg font-bold hover:bg-cream-100 transition-all duration-300 transform hover:scale-105 shadow-classic font-serif">
              Apply Now
            </button>
            <button className="border-2 border-white text-white hover:bg-white hover:text-gold-600 px-10 py-4 rounded-lg text-lg font-bold transition-all duration-300 shadow-elegant font-serif">
              Download Brochure
            </button>
          </motion.div>
        </div>
      </section>
    </motion.div>
  );
};

export default Home;