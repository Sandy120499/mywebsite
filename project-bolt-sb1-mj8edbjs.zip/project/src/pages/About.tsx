import React from 'react';
import { motion } from 'framer-motion';
import { Award, Users, Building, Target, Eye, Heart, BookOpen, Trophy, Star, Globe } from 'lucide-react';

const About = () => {
  const milestones = [
    { year: '1985', title: 'Institute Founded', description: 'Established with a vision to provide world-class hospitality education' },
    { year: '1992', title: 'First Graduation Batch', description: '120 students successfully placed in leading international hotels' },
    { year: '2000', title: 'International Recognition', description: 'Accredited by World Tourism Organization and UNESCO' },
    { year: '2010', title: 'Campus Expansion', description: 'New state-of-the-art facilities meeting international standards' },
    { year: '2018', title: 'Digital Learning', description: 'Integrated technology-enabled learning platforms and virtual reality training' },
    { year: '2024', title: 'Global Innovation Hub', description: 'Launched international hospitality innovation and research center' }
  ];

  const faculty = [
    {
      name: 'Dr. Rajesh Sharma',
      position: 'Principal & Director',
      experience: '25 years',
      expertise: 'International Hotel Operations, Strategic Management',
      image: 'https://images.pexels.com/photos/3785079/pexels-photo-3785079.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop'
    },
    {
      name: 'Chef Priya Patel',
      position: 'Head of Culinary Arts',
      experience: '18 years',
      expertise: 'International Cuisine, Michelin Star Experience',
      image: 'https://images.pexels.com/photos/3785077/pexels-photo-3785077.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop'
    },
    {
      name: 'Mr. Amit Kumar',
      position: 'Department Head - Front Office',
      experience: '20 years',
      expertise: 'Global Guest Relations, Revenue Management',
      image: 'https://images.pexels.com/photos/3785078/pexels-photo-3785078.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop'
    },
    {
      name: 'Ms. Neha Singh',
      position: 'Head of Event Management',
      experience: '15 years',
      expertise: 'International Events, Luxury Wedding Planning',
      image: 'https://images.pexels.com/photos/3785080/pexels-photo-3785080.jpeg?auto=compress&cs=tinysrgb&w=300&h=300&fit=crop'
    }
  ];

  const facilities = [
    {
      title: 'International Kitchen Labs',
      description: 'World-class culinary facilities with latest European equipment',
      icon: Building,
      color: 'from-navy-600 to-navy-700'
    },
    {
      title: 'Global Training Restaurant',
      description: 'Full-service restaurant simulating international hotel standards',
      icon: Users,
      color: 'from-gold-500 to-gold-600'
    },
    {
      title: 'Smart Technology Labs',
      description: 'Advanced technology labs with global hospitality software',
      icon: BookOpen,
      color: 'from-emerald-500 to-emerald-600'
    },
    {
      title: 'International Library',
      description: 'Comprehensive collection of global hospitality resources',
      icon: Award,
      color: 'from-navy-500 to-gold-500'
    }
  ];

  const achievements = [
    'Best International Hospitality Institute Award 2023',
    'Excellence in Global Culinary Education',
    'UNESCO Partnership Recognition',
    'International Student Placement Achievement Award',
    'Innovation in Global Teaching Methodology',
    'World Tourism Organization Accreditation'
  ];

  const partners = [
    {
      name: 'Taj Hotels',
      logo: 'https://images.pexels.com/photos/271639/pexels-photo-271639.jpeg?auto=compress&cs=tinysrgb&w=200&h=100&fit=crop',
      category: 'Luxury Hotels',
      global: true
    },
    {
      name: 'ITC Hotels',
      logo: 'https://images.pexels.com/photos/3184183/pexels-photo-3184183.jpeg?auto=compress&cs=tinysrgb&w=200&h=100&fit=crop',
      category: 'Premium Hotels',
      global: true
    },
    {
      name: 'Oberoi Group',
      logo: 'https://images.pexels.com/photos/3616956/pexels-photo-3616956.jpeg?auto=compress&cs=tinysrgb&w=200&h=100&fit=crop',
      category: 'Luxury Hospitality',
      global: true
    },
    {
      name: 'Marriott International',
      logo: 'https://images.pexels.com/photos/3662120/pexels-photo-3662120.jpeg?auto=compress&cs=tinysrgb&w=200&h=100&fit=crop',
      category: 'Global Hotels',
      global: true
    },
    {
      name: 'Hyatt Hotels',
      logo: 'https://images.pexels.com/photos/1190298/pexels-photo-1190298.jpeg?auto=compress&cs=tinysrgb&w=200&h=100&fit=crop',
      category: 'International Chain',
      global: true
    },
    {
      name: 'Radisson Hotels',
      logo: 'https://images.pexels.com/photos/3184194/pexels-photo-3184194.jpeg?auto=compress&cs=tinysrgb&w=200&h=100&fit=crop',
      category: 'Business Hotels',
      global: true
    },
    {
      name: 'Four Seasons',
      logo: 'https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg?auto=compress&cs=tinysrgb&w=200&h=100&fit=crop',
      category: 'Ultra Luxury',
      global: true
    },
    {
      name: 'Hilton Worldwide',
      logo: 'https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=200&h=100&fit=crop',
      category: 'Global Hospitality',
      global: true
    },
    {
      name: 'Accor Hotels',
      logo: 'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=200&h=100&fit=crop',
      category: 'European Chain',
      global: true
    }
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen pt-32 pb-20"
    >
      {/* Header */}
      <section className="bg-navy-900 text-white py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-hero-pattern opacity-10"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <motion.h1
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8 }}
            className="text-5xl md:text-6xl font-bold mb-8"
          >
            About <span className="text-gold-400">Empee Institute</span>
          </motion.h1>
          <motion.p
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-xl text-platinum-200 max-w-4xl mx-auto leading-relaxed"
          >
            Pioneering international hospitality education for over three decades, shaping the future 
            leaders of the global hospitality industry
          </motion.p>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <motion.div
              initial={{ x: -50, opacity: 0 }}
              whileInView={{ x: 0, opacity: 1 }}
              transition={{ duration: 0.8 }}
              className="bg-gradient-to-br from-navy-50 to-platinum-50 p-10 rounded-xl shadow-premium border border-navy-100"
            >
              <div className="flex items-center mb-8">
                <div className="bg-gradient-to-r from-navy-600 to-navy-700 p-4 rounded-xl mr-6">
                  <Target className="w-10 h-10 text-white" />
                </div>
                <h2 className="text-4xl font-bold text-navy-900">Our Mission</h2>
              </div>
              <p className="text-lg text-navy-700 leading-relaxed">
                To provide world-class hospitality education that meets international standards, combining 
                theoretical knowledge with practical experience, preparing students to excel in the global 
                hospitality industry while maintaining the highest standards of service and professionalism.
              </p>
            </motion.div>

            <motion.div
              initial={{ x: 50, opacity: 0 }}
              whileInView={{ x: 0, opacity: 1 }}
              transition={{ duration: 0.8 }}
              className="bg-gradient-to-br from-gold-50 to-platinum-50 p-10 rounded-xl shadow-premium border border-gold-100"
            >
              <div className="flex items-center mb-8">
                <div className="bg-gradient-to-r from-gold-500 to-gold-600 p-4 rounded-xl mr-6">
                  <Eye className="w-10 h-10 text-white" />
                </div>
                <h2 className="text-4xl font-bold text-navy-900">Our Vision</h2>
              </div>
              <p className="text-lg text-navy-700 leading-relaxed">
                To be the leading international hospitality education institution, recognized globally 
                for innovation, excellence, and creating industry-ready professionals who contribute 
                to the growth and development of the global hospitality sector.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-20 bg-gradient-to-br from-platinum-50 to-navy-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-bold mb-6 text-navy-900">
              Our <span className="text-gold-600">Journey</span>
            </h2>
            <p className="text-xl text-navy-600 max-w-3xl mx-auto">
              Four decades of excellence in international hospitality education
            </p>
          </div>

          <div className="relative">
            <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-1 bg-gradient-to-b from-navy-600 via-gold-500 to-navy-600"></div>
            {milestones.map((milestone, index) => (
              <motion.div
                key={index}
                initial={{ y: 50, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className={`relative flex items-center mb-16 ${
                  index % 2 === 0 ? 'flex-row' : 'flex-row-reverse'
                }`}
              >
                <div className={`w-1/2 ${index % 2 === 0 ? 'pr-12' : 'pl-12'}`}>
                  <div className="bg-white p-8 rounded-xl shadow-premium hover:shadow-luxury transition-all duration-300 transform hover:scale-105 border border-platinum-200">
                    <div className="bg-gradient-to-r from-gold-500 to-gold-600 text-white text-xl font-bold mb-4 px-4 py-2 rounded-lg inline-block">{milestone.year}</div>
                    <h3 className="text-2xl font-bold text-navy-900 mb-4">{milestone.title}</h3>
                    <p className="text-navy-600 leading-relaxed">{milestone.description}</p>
                  </div>
                </div>
                <div className="absolute left-1/2 transform -translate-x-1/2 w-6 h-6 bg-gradient-to-r from-gold-500 to-gold-600 rounded-full border-4 border-white shadow-elegant"></div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Faculty */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-bold mb-6 text-navy-900">
              Our <span className="text-gold-600">Faculty</span>
            </h2>
            <p className="text-xl text-navy-600 max-w-3xl mx-auto">
              Learn from international experts with decades of global experience
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {faculty.map((member, index) => (
              <motion.div
                key={index}
                initial={{ y: 50, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="bg-white rounded-xl shadow-premium overflow-hidden hover:shadow-luxury transition-all duration-300 transform hover:scale-105 border border-platinum-200"
              >
                <div className="relative overflow-hidden">
                  <img
                    src={member.image}
                    alt={member.name}
                    className="w-full h-64 object-cover transform hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-navy-900/50 to-transparent"></div>
                </div>
                <div className="p-8">
                  <h3 className="text-xl font-bold text-navy-900 mb-2">{member.name}</h3>
                  <p className="text-gold-600 font-semibold mb-2">{member.position}</p>
                  <p className="text-sm text-navy-600 mb-3 font-medium">{member.experience} Experience</p>
                  <p className="text-navy-700 text-sm leading-relaxed">{member.expertise}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Global Industry Partners */}
      <section className="py-20 bg-gradient-to-br from-platinum-50 to-navy-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-bold mb-6 text-navy-900">
              Our <span className="text-gold-600">Global Partners</span>
            </h2>
            <p className="text-xl text-navy-600 max-w-3xl mx-auto">
              Collaborating with leading international hospitality brands for global placement opportunities
            </p>
            <div className="flex items-center justify-center mt-6">
              <Globe className="w-6 h-6 text-gold-600 mr-2" />
              <span className="text-gold-600 font-semibold">International Standards & Partnerships</span>
            </div>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
            {partners.map((partner, index) => (
              <motion.div
                key={index}
                initial={{ y: 50, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                transition={{ duration: 0.6, delay: index * 0.05 }}
                className="bg-white p-6 rounded-xl shadow-premium hover:shadow-luxury transition-all duration-300 transform hover:scale-105 border border-platinum-200 text-center group relative"
              >
                {partner.global && (
                  <div className="absolute top-2 right-2 bg-gold-500 text-white text-xs px-2 py-1 rounded-full font-semibold">
                    Global
                  </div>
                )}
                <div className="relative overflow-hidden rounded-lg mb-4">
                  <img
                    src={partner.logo}
                    alt={partner.name}
                    className="w-full h-16 object-cover transform group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-navy-900/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
                </div>
                <h3 className="font-bold text-navy-900 mb-1 text-sm">{partner.name}</h3>
                <p className="text-xs text-gold-600 font-medium">{partner.category}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Facilities */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-bold mb-6 text-navy-900">
              World-Class <span className="text-gold-600">Facilities</span>
            </h2>
            <p className="text-xl text-navy-600 max-w-3xl mx-auto">
              International standard infrastructure designed for optimal learning
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {facilities.map((facility, index) => (
              <motion.div
                key={index}
                initial={{ y: 50, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="bg-white p-8 rounded-xl shadow-premium text-center hover:shadow-luxury transition-all duration-300 transform hover:scale-105 border border-platinum-200"
              >
                <div className={`bg-gradient-to-r ${facility.color} w-20 h-20 rounded-xl flex items-center justify-center mx-auto mb-6 shadow-elegant`}>
                  <facility.icon className="w-10 h-10 text-white" />
                </div>
                <h3 className="text-xl font-bold text-navy-900 mb-4">{facility.title}</h3>
                <p className="text-navy-600 leading-relaxed">{facility.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Achievements */}
      <section className="py-20 bg-navy-900 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-hero-pattern opacity-5"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-bold mb-6">Our Achievements</h2>
            <p className="text-xl text-platinum-300 max-w-3xl mx-auto">
              Recognition for excellence in international hospitality education
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {achievements.map((achievement, index) => (
              <motion.div
                key={index}
                initial={{ y: 50, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="bg-white/10 backdrop-blur-lg p-8 rounded-xl border border-white/20 hover:bg-white/20 transition-all duration-300 transform hover:scale-105"
              >
                <div className="bg-gradient-to-r from-gold-500 to-gold-600 p-3 rounded-lg w-fit mb-6">
                  <Trophy className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-lg font-bold text-white leading-tight">{achievement}</h3>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-bold mb-6 text-navy-900">
              Our <span className="text-gold-600">Values</span>
            </h2>
            <p className="text-xl text-navy-600 max-w-3xl mx-auto">
              The principles that guide everything we do in international hospitality education
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <motion.div
              initial={{ y: 50, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.6 }}
              className="text-center"
            >
              <div className="bg-gradient-to-r from-navy-600 to-navy-700 w-24 h-24 rounded-xl flex items-center justify-center mx-auto mb-8 shadow-premium">
                <Heart className="w-12 h-12 text-white" />
              </div>
              <h3 className="text-3xl font-bold text-navy-900 mb-6">Excellence</h3>
              <p className="text-navy-600 leading-relaxed text-lg">
                We strive for excellence in everything we do, from teaching to student support, 
                ensuring the highest quality international education standards.
              </p>
            </motion.div>

            <motion.div
              initial={{ y: 50, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-center"
            >
              <div className="bg-gradient-to-r from-gold-500 to-gold-600 w-24 h-24 rounded-xl flex items-center justify-center mx-auto mb-8 shadow-premium">
                <Star className="w-12 h-12 text-white" />
              </div>
              <h3 className="text-3xl font-bold text-navy-900 mb-6">Innovation</h3>
              <p className="text-navy-600 leading-relaxed text-lg">
                We embrace innovation in our teaching methods, curriculum design, and 
                educational technology to stay ahead of global industry trends.
              </p>
            </motion.div>

            <motion.div
              initial={{ y: 50, opacity: 0 }}
              whileInView={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="text-center"
            >
              <div className="bg-gradient-to-r from-emerald-500 to-emerald-600 w-24 h-24 rounded-xl flex items-center justify-center mx-auto mb-8 shadow-premium">
                <Award className="w-12 h-12 text-white" />
              </div>
              <h3 className="text-3xl font-bold text-navy-900 mb-6">Integrity</h3>
              <p className="text-navy-600 leading-relaxed text-lg">
                We maintain the highest standards of integrity in all our interactions, 
                fostering trust and respect in our global community.
              </p>
            </motion.div>
          </div>
        </div>
      </section>
    </motion.div>
  );
};

export default About;