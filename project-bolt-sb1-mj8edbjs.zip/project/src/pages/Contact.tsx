import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { MapPin, Phone, Mail, Clock, Send, CheckCircle, Facebook, Twitter, Instagram, Youtube, Globe } from 'lucide-react';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    course: '',
    message: ''
  });
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
    setIsSubmitted(true);
    setTimeout(() => setIsSubmitted(false), 3000);
  };

  const contactInfo = [
    {
      icon: MapPin,
      title: 'Address',
      details: ['123 Hospitality Boulevard', 'Education District', 'Mumbai - 400001'],
      color: 'from-navy-600 to-navy-700'
    },
    {
      icon: Phone,
      title: 'Phone',
      details: ['+91 98765 43210', '+91 98765 43211'],
      color: 'from-gold-500 to-gold-600'
    },
    {
      icon: Mail,
      title: 'Email',
      details: ['admissions@empeeihm.edu', 'info@empeeihm.edu'],
      color: 'from-emerald-500 to-emerald-600'
    },
    {
      icon: Clock,
      title: 'Office Hours',
      details: ['Monday - Friday: 9:00 AM - 6:00 PM', 'Saturday: 9:00 AM - 2:00 PM'],
      color: 'from-navy-500 to-gold-500'
    }
  ];

  const departments = [
    { name: 'International Admissions', email: 'admissions@empeeihm.edu', phone: '+91 98765 43210' },
    { name: 'Academic Affairs', email: 'academic@empeeihm.edu', phone: '+91 98765 43211' },
    { name: 'Student Services', email: 'students@empeeihm.edu', phone: '+91 98765 43212' },
    { name: 'Global Placement Cell', email: 'placement@empeeihm.edu', phone: '+91 98765 43213' },
    { name: 'International Office', email: 'international@empeeihm.edu', phone: '+91 98765 43214' },
    { name: 'Alumni Relations', email: 'alumni@empeeihm.edu', phone: '+91 98765 43215' }
  ];

  const socialLinks = [
    { icon: Facebook, href: '#', color: 'from-blue-500 to-blue-600' },
    { icon: Twitter, href: '#', color: 'from-cyan-500 to-blue-500' },
    { icon: Instagram, href: '#', color: 'from-pink-500 to-purple-500' },
    { icon: Youtube, href: '#', color: 'from-red-500 to-pink-500' }
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="min-h-screen pt-32 pb-20"
    >
      {/* Header */}
      <section className="bg-navy-900 text-white py-20 relative overflow-hidden">
        <div className="absolute inset-0 bg-hero-pattern opacity-10"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <motion.h1
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8 }}
            className="text-5xl md:text-6xl font-bold mb-8"
          >
            Contact <span className="text-gold-400">Us</span>
          </motion.h1>
          <motion.p
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-xl text-platinum-200 max-w-4xl mx-auto leading-relaxed"
          >
            Get in touch with us for international admissions, information, or any questions about our global programs
          </motion.p>
          <motion.div
            initial={{ y: 30, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="flex items-center justify-center mt-6"
          >
            <Globe className="w-6 h-6 text-gold-400 mr-2" />
            <span className="text-gold-400 font-semibold">International Standards & Global Support</span>
          </motion.div>
        </div>
      </section>

      {/* Contact Information */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {contactInfo.map((info, index) => (
              <motion.div
                key={index}
                initial={{ y: 50, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="text-center p-8 bg-white rounded-xl hover:shadow-luxury transition-all duration-300 transform hover:scale-105 border border-platinum-200 shadow-premium"
              >
                <div className={`inline-flex items-center justify-center w-20 h-20 rounded-xl bg-gradient-to-r ${info.color} mb-6 shadow-elegant`}>
                  <info.icon className="w-10 h-10 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-navy-900 mb-4">{info.title}</h3>
                {info.details.map((detail, idx) => (
                  <p key={idx} className="text-navy-600 mb-2 font-medium">{detail}</p>
                ))}
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Form & Map */}
      <section className="py-20 bg-gradient-to-br from-platinum-50 to-navy-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            {/* Contact Form */}
            <motion.div
              initial={{ x: -50, opacity: 0 }}
              whileInView={{ x: 0, opacity: 1 }}
              transition={{ duration: 0.8 }}
              className="bg-white p-10 rounded-xl shadow-luxury border border-platinum-200"
            >
              <h2 className="text-4xl font-bold text-navy-900 mb-8">Send us a Message</h2>
              
              {isSubmitted && (
                <motion.div
                  initial={{ y: -20, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  className="bg-green-100 border border-green-300 text-green-700 px-6 py-4 rounded-xl mb-8 flex items-center shadow-elegant"
                >
                  <CheckCircle className="w-6 h-6 mr-3" />
                  Thank you! Your message has been sent successfully.
                </motion.div>
              )}

              <form onSubmit={handleSubmit} className="space-y-8">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="name" className="block text-sm font-bold text-navy-900 mb-3">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      required
                      value={formData.name}
                      onChange={handleInputChange}
                      className="w-full px-6 py-4 border border-platinum-300 rounded-lg focus:ring-2 focus:ring-navy-500 focus:border-transparent transition-all duration-300 bg-platinum-50"
                    />
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-sm font-bold text-navy-900 mb-3">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      required
                      value={formData.email}
                      onChange={handleInputChange}
                      className="w-full px-6 py-4 border border-platinum-300 rounded-lg focus:ring-2 focus:ring-navy-500 focus:border-transparent transition-all duration-300 bg-platinum-50"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="phone" className="block text-sm font-bold text-navy-900 mb-3">
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      value={formData.phone}
                      onChange={handleInputChange}
                      className="w-full px-6 py-4 border border-platinum-300 rounded-lg focus:ring-2 focus:ring-navy-500 focus:border-transparent transition-all duration-300 bg-platinum-50"
                    />
                  </div>
                  <div>
                    <label htmlFor="course" className="block text-sm font-bold text-navy-900 mb-3">
                      Course of Interest
                    </label>
                    <select
                      id="course"
                      name="course"
                      value={formData.course}
                      onChange={handleInputChange}
                      className="w-full px-6 py-4 border border-platinum-300 rounded-lg focus:ring-2 focus:ring-navy-500 focus:border-transparent transition-all duration-300 bg-platinum-50"
                    >
                      <option value="">Select a course</option>
                      <option value="international-hotel-management">International Hotel Management</option>
                      <option value="global-culinary-arts">Global Culinary Arts</option>
                      <option value="international-event-management">International Event Management</option>
                      <option value="global-tourism-management">Global Tourism Management</option>
                      <option value="international-food-beverage">International Food & Beverage</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label htmlFor="message" className="block text-sm font-bold text-navy-900 mb-3">
                    Message *
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    rows={6}
                    required
                    value={formData.message}
                    onChange={handleInputChange}
                    className="w-full px-6 py-4 border border-platinum-300 rounded-lg focus:ring-2 focus:ring-navy-500 focus:border-transparent transition-all duration-300 bg-platinum-50"
                    placeholder="Tell us about your inquiry..."
                  />
                </div>

                <button
                  type="submit"
                  className="w-full bg-gradient-to-r from-navy-600 to-navy-700 hover:from-navy-700 hover:to-navy-800 text-white px-8 py-4 rounded-lg font-bold transition-all duration-300 flex items-center justify-center space-x-3 shadow-premium transform hover:scale-105"
                >
                  <Send className="w-6 h-6" />
                  <span>Send Message</span>
                </button>
              </form>
            </motion.div>

            {/* Map & Additional Info */}
            <motion.div
              initial={{ x: 50, opacity: 0 }}
              whileInView={{ x: 0, opacity: 1 }}
              transition={{ duration: 0.8 }}
              className="space-y-8"
            >
              {/* Map */}
              <div className="bg-white rounded-xl shadow-luxury overflow-hidden border border-platinum-200">
                <div className="h-80 bg-gradient-to-br from-navy-100 to-gold-100 flex items-center justify-center">
                  <div className="text-center">
                    <div className="bg-gradient-to-r from-navy-600 to-gold-600 w-20 h-20 rounded-xl flex items-center justify-center mx-auto mb-6">
                      <MapPin className="w-10 h-10 text-white" />
                    </div>
                    <h3 className="text-2xl font-bold text-navy-900 mb-3">Visit Our International Campus</h3>
                    <p className="text-navy-600 font-medium">Interactive map coming soon</p>
                  </div>
                </div>
              </div>

              {/* Social Media */}
              <div className="bg-white p-8 rounded-xl shadow-luxury border border-platinum-200">
                <h3 className="text-2xl font-bold text-navy-900 mb-6">Connect With Us Globally</h3>
                <p className="text-navy-600 mb-6 font-medium">Follow us on social media for international updates and news</p>
                <div className="flex space-x-4">
                  {socialLinks.map((social, index) => (
                    <a
                      key={index}
                      href={social.href}
                      className={`w-14 h-14 bg-gradient-to-r ${social.color} rounded-lg flex items-center justify-center text-white transition-all duration-300 transform hover:scale-110 shadow-elegant`}
                    >
                      <social.icon className="w-7 h-7" />
                    </a>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Department Contacts */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold mb-6 text-navy-900">
              Department <span className="text-gold-600">Contacts</span>
            </h2>
            <p className="text-xl text-navy-600 max-w-3xl mx-auto">
              Contact specific departments for specialized international assistance
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {departments.map((dept, index) => (
              <motion.div
                key={index}
                initial={{ y: 50, opacity: 0 }}
                whileInView={{ y: 0, opacity: 1 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="bg-gradient-to-br from-navy-50 to-gold-50 p-8 rounded-xl hover:shadow-luxury transition-all duration-300 transform hover:scale-105 border border-platinum-200 shadow-premium"
              >
                <h3 className="text-xl font-bold text-navy-900 mb-6">{dept.name}</h3>
                <div className="space-y-4">
                  <div className="flex items-center text-navy-700">
                    <div className="bg-gradient-to-r from-gold-500 to-gold-600 p-2 rounded-lg mr-4">
                      <Mail className="w-5 h-5 text-white" />
                    </div>
                    <a href={`mailto:${dept.email}`} className="hover:text-gold-600 transition-colors font-medium">
                      {dept.email}
                    </a>
                  </div>
                  <div className="flex items-center text-navy-700">
                    <div className="bg-gradient-to-r from-navy-600 to-navy-700 p-2 rounded-lg mr-4">
                      <Phone className="w-5 h-5 text-white" />
                    </div>
                    <a href={`tel:${dept.phone}`} className="hover:text-gold-600 transition-colors font-medium">
                      {dept.phone}
                    </a>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Emergency Contacts */}
      <section className="py-20 bg-navy-900 text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-hero-pattern opacity-5"></div>
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <motion.h2
            initial={{ y: 30, opacity: 0 }}
            whileInView={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.8 }}
            className="text-4xl font-bold mb-12"
          >
            Emergency Contacts
          </motion.h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white/10 backdrop-blur-lg p-8 rounded-xl border border-white/20">
              <h3 className="text-2xl font-bold text-gold-400 mb-6">Campus Security</h3>
              <p className="text-3xl font-bold mb-3">+91 98765 43299</p>
              <p className="text-platinum-300 font-medium">24/7 Emergency Response</p>
            </div>
            <div className="bg-white/10 backdrop-blur-lg p-8 rounded-xl border border-white/20">
              <h3 className="text-2xl font-bold text-gold-400 mb-6">Medical Emergency</h3>
              <p className="text-3xl font-bold mb-3">+91 98765 43298</p>
              <p className="text-platinum-300 font-medium">Campus Medical Center</p>
            </div>
          </div>
        </div>
      </section>
    </motion.div>
  );
};

export default Contact;