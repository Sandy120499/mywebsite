import React from 'react';
import { Phone, Mail, MapPin, Facebook, Instagram, Linkedin, Twitter, GraduationCap } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-primary text-white">
      <div className="container py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Institute Info */}
          <div className="space-y-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-accent rounded-full flex items-center justify-center">
                <GraduationCap className="text-white" size={20} />
              </div>
              <div>
                <h3 className="font-bold text-lg">Empee Institute</h3>
                <p className="text-sm text-gray-300">Hotel Management</p>
              </div>
            </div>
            <p className="text-gray-300 text-sm leading-relaxed">
              Leading hospitality education institute providing world-class training 
              and career opportunities in hotel management and hospitality services.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="hover:text-accent transition-colors">
                <Facebook size={18} />
              </a>
              <a href="#" className="hover:text-accent transition-colors">
                <Instagram size={18} />
              </a>
              <a href="#" className="hover:text-accent transition-colors">
                <Linkedin size={18} />
              </a>
              <a href="#" className="hover:text-accent transition-colors">
                <Twitter size={18} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold mb-4">Quick Links</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="/courses" className="text-gray-300 hover:text-accent transition-colors">Graduate Programs</a></li>
              <li><a href="/courses" className="text-gray-300 hover:text-accent transition-colors">Diploma Courses</a></li>
              <li><a href="/courses" className="text-gray-300 hover:text-accent transition-colors">Short-term Certificates</a></li>
              <li><a href="/about" className="text-gray-300 hover:text-accent transition-colors">About Us</a></li>
              <li><a href="/gallery" className="text-gray-300 hover:text-accent transition-colors">Gallery</a></li>
            </ul>
          </div>

          {/* Programs */}
          <div>
            <h4 className="font-semibold mb-4">Popular Programs</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="/courses" className="text-gray-300 hover:text-accent transition-colors">Hotel Management</a></li>
              <li><a href="/courses" className="text-gray-300 hover:text-accent transition-colors">Culinary Arts</a></li>
              <li><a href="/courses" className="text-gray-300 hover:text-accent transition-colors">Food & Beverage</a></li>
              <li><a href="/courses" className="text-gray-300 hover:text-accent transition-colors">Hospitality Management</a></li>
              <li><a href="/courses" className="text-gray-300 hover:text-accent transition-colors">Event Management</a></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="font-semibold mb-4">Contact Info</h4>
            <div className="space-y-3 text-sm">
              <div className="flex items-start space-x-3">
                <MapPin size={16} className="text-accent mt-1 flex-shrink-0" />
                <div>
                  <p className="text-gray-300">123 Education Street</p>
                  <p className="text-gray-300">Hotel District, City - 123456</p>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Phone size={16} className="text-accent" />
                <span className="text-gray-300">+91 98765 43210</span>
              </div>
              <div className="flex items-center space-x-3">
                <Mail size={16} className="text-accent" />
                <span className="text-gray-300">info@empeehotel.edu</span>
              </div>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-600 mt-8 pt-8 text-center text-sm text-gray-400">
          <p>&copy; 2024 Empee Institute of Hotel Management. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;