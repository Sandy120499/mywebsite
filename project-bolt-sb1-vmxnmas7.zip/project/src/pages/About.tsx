import React, { useState } from 'react';
import { useInView } from 'react-intersection-observer';
import { Target, Eye, Users, Award, BookOpen, Globe, Calendar, CheckCircle } from 'lucide-react';

const About: React.FC = () => {
  const [activeTimelineItem, setActiveTimelineItem] = useState(0);
  const [ref, inView] = useInView({ triggerOnce: true, threshold: 0.1 });

  const timelineEvents = [
    {
      year: "2000",
      title: "Foundation",
      description: "Empee Institute established with a vision to provide quality hospitality education."
    },
    {
      year: "2005",
      title: "First Graduates",
      description: "Our first batch of 50 students graduated with 100% placement record."
    },
    {
      year: "2010",
      title: "Campus Expansion",
      description: "New state-of-the-art facilities including modern kitchens and training restaurants."
    },
    {
      year: "2015",
      title: "International Recognition",
      description: "Received accreditation from International Hotel Management Institute, Switzerland."
    },
    {
      year: "2020",
      title: "Digital Innovation",
      description: "Launched online learning platform and virtual reality training modules."
    },
    {
      year: "2024",
      title: "Excellence Milestone",
      description: "Celebrating 24 years of excellence with over 5000 successful graduates."
    }
  ];

  const achievements = [
    { number: "5000+", label: "Graduates", icon: <Users className="text-accent" size={24} /> },
    { number: "95%", label: "Placement Rate", icon: <Award className="text-accent" size={24} /> },
    { number: "200+", label: "Industry Partners", icon: <Globe className="text-accent" size={24} /> },
    { number: "24", label: "Years of Excellence", icon: <Calendar className="text-accent" size={24} /> }
  ];

  const partners = [
    "Marriott International", "Hilton Hotels", "Taj Hotels", "ITC Hotels", 
    "Oberoi Group", "Hyatt Hotels", "Radisson Hotel Group", "AccorHotels"
  ];

  return (
    <div className="min-h-screen pt-32">
      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-to-r from-primary to-secondary text-white">
        <div className="container">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">About Empee Institute</h1>
            <p className="text-xl md:text-2xl mb-8">
              Pioneering excellence in hospitality education for over two decades
            </p>
          </div>
        </div>
      </section>

      {/* Vision & Mission */}
      <section className="section bg-light-gray">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div className="card p-8 text-center">
              <div className="flex justify-center mb-6">
                <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center">
                  <Eye className="text-white" size={32} />
                </div>
              </div>
              <h3 className="text-2xl font-bold mb-4">Our Vision</h3>
              <p className="text-gray-600 leading-relaxed">
                To be the premier institution for hospitality education, recognized globally for our commitment to excellence, 
                innovation, and the development of industry leaders who will shape the future of hospitality.
              </p>
            </div>

            <div className="card p-8 text-center">
              <div className="flex justify-center mb-6">
                <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center">
                  <Target className="text-white" size={32} />
                </div>
              </div>
              <h3 className="text-2xl font-bold mb-4">Our Mission</h3>
              <p className="text-gray-600 leading-relaxed">
                To provide comprehensive, industry-relevant education and training that prepares students for successful careers 
                in hospitality, while fostering innovation, ethical practices, and service excellence.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="section">
        <div className="container">
          <h2 className="section-title">Our Journey</h2>
          <div className="relative">
            {/* Timeline Line */}
            <div className="absolute left-1/2 transform -translate-x-1/2 w-1 bg-accent h-full hidden md:block"></div>
            
            <div className="space-y-8">
              {timelineEvents.map((event, index) => (
                <div 
                  key={index}
                  className={`relative flex items-center ${
                    index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'
                  }`}
                >
                  {/* Timeline Dot */}
                  <div className="absolute left-1/2 transform -translate-x-1/2 w-6 h-6 bg-accent rounded-full border-4 border-white shadow-lg hidden md:block z-10"></div>
                  
                  {/* Content */}
                  <div className={`w-full md:w-1/2 ${index % 2 === 0 ? 'md:pr-8' : 'md:pl-8'}`}>
                    <div className="card p-6 hover:shadow-lg transition-shadow">
                      <div className="flex items-center space-x-3 mb-3">
                        <div className="w-8 h-8 bg-accent rounded-full flex items-center justify-center">
                          <span className="text-white font-bold text-sm">{event.year}</span>
                        </div>
                        <h3 className="text-xl font-semibold">{event.title}</h3>
                      </div>
                      <p className="text-gray-600">{event.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Chairman's Message */}
      <section className="section bg-light-gray">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <img
                src="https://images.pexels.com/photos/3778876/pexels-photo-3778876.jpeg?auto=compress&cs=tinysrgb&w=600"
                alt="Chairman"
                className="rounded-lg shadow-lg"
              />
            </div>
            <div>
              <h2 className="text-3xl font-bold mb-6">Chairman's Message</h2>
              <div className="bg-white p-6 rounded-lg shadow-md">
                <p className="text-gray-600 mb-4 italic">
                  "Over the past 24 years, we have witnessed the hospitality industry evolve dramatically. 
                  At Empee Institute, we have consistently adapted our curriculum to meet these changing needs while 
                  maintaining our commitment to excellence."
                </p>
                <p className="text-gray-600 mb-4">
                  "Our graduates don't just find jobs; they become leaders who drive innovation and set new standards 
                  in hospitality. We take pride in our holistic approach to education that combines theoretical knowledge 
                  with practical experience."
                </p>
                <div className="border-t pt-4">
                  <h4 className="font-semibold">Dr. Rajesh Sharma</h4>
                  <p className="text-sm text-gray-500">Chairman & Managing Director</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Achievements */}
      <section className="section" ref={ref}>
        <div className="container">
          <h2 className="section-title">Our Achievements</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {achievements.map((achievement, index) => (
              <div key={index} className={`text-center fade-in ${inView ? 'visible' : ''}`}>
                <div className="flex justify-center mb-4">
                  {achievement.icon}
                </div>
                <div className="text-4xl font-bold text-accent mb-2">{achievement.number}</div>
                <div className="text-gray-600">{achievement.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Industry Partners */}
      <section className="section bg-light-gray">
        <div className="container">
          <h2 className="section-title">Industry Partnerships</h2>
          <p className="text-center text-gray-600 mb-12 max-w-3xl mx-auto">
            We collaborate with leading hospitality brands worldwide to provide our students with real-world experience 
            and excellent career opportunities.
          </p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {partners.map((partner, index) => (
              <div key={index} className="text-center">
                <div className="bg-white rounded-lg p-6 shadow-md hover:shadow-lg transition-shadow">
                  <div className="text-4xl mb-3">🏨</div>
                  <h4 className="font-medium text-gray-800">{partner}</h4>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Educational Roadmap */}
      <section className="section">
        <div className="container">
          <h2 className="section-title">Educational Roadmap</h2>
          <div className="bg-gradient-to-r from-primary to-secondary text-white rounded-lg p-8">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="text-center">
                <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center mx-auto mb-4">
                  <BookOpen className="text-white" size={32} />
                </div>
                <h3 className="text-xl font-semibold mb-3">Foundation</h3>
                <p className="text-gray-200">
                  Strong theoretical foundation combined with practical skills development
                </p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="text-white" size={32} />
                </div>
                <h3 className="text-xl font-semibold mb-3">Experience</h3>
                <p className="text-gray-200">
                  Real-world experience through internships and industry projects
                </p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 bg-accent rounded-full flex items-center justify-center mx-auto mb-4">
                  <Award className="text-white" size={32} />
                </div>
                <h3 className="text-xl font-semibold mb-3">Excellence</h3>
                <p className="text-gray-200">
                  Career placement and ongoing professional development support
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;