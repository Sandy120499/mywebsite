import React, { useState } from 'react';
import { Clock, Users, Award, BookOpen, ChefHat, Calendar, CheckCircle, ArrowRight } from 'lucide-react';

const Courses: React.FC = () => {
  const [activeTab, setActiveTab] = useState('graduate');
  const [flippedCard, setFlippedCard] = useState<number | null>(null);

  const courseCategories = {
    graduate: {
      title: "Graduate Programs",
      icon: <Award className="text-accent" size={24} />,
      courses: [
        {
          title: "Bachelor of Hotel Management",
          duration: "3 Years",
          fee: "₹2,50,000",
          description: "Comprehensive program covering all aspects of hospitality management including operations, marketing, finance, and human resources.",
          requirements: ["10+2 with minimum 50% marks", "Entrance exam", "Personal interview"],
          highlights: ["Industry internships", "International exposure", "Placement assistance"],
          image: "https://images.pexels.com/photos/941861/pexels-photo-941861.jpeg?auto=compress&cs=tinysrgb&w=400"
        },
        {
          title: "Master of Hotel Management",
          duration: "2 Years",
          fee: "₹3,50,000",
          description: "Advanced program designed for working professionals and graduates seeking leadership roles in hospitality industry.",
          requirements: ["Bachelor's degree", "Work experience preferred", "GMAT/GRE scores"],
          highlights: ["Executive curriculum", "Industry mentorship", "Global networking"],
          image: "https://images.pexels.com/photos/1449773/pexels-photo-1449773.jpeg?auto=compress&cs=tinysrgb&w=400"
        }
      ]
    },
    diploma: {
      title: "Diploma Courses",
      icon: <BookOpen className="text-accent" size={24} />,
      courses: [
        {
          title: "Diploma in Hotel Management",
          duration: "1 Year",
          fee: "₹1,20,000",
          description: "Intensive program covering fundamentals of hotel operations, guest services, and hospitality management.",
          requirements: ["10+2 completion", "Basic English proficiency", "Aptitude test"],
          highlights: ["Practical training", "Industry exposure", "Job placement"],
          image: "https://images.pexels.com/photos/260922/pexels-photo-260922.jpeg?auto=compress&cs=tinysrgb&w=400"
        },
        {
          title: "Diploma in Culinary Arts",
          duration: "1 Year",
          fee: "₹1,50,000",
          description: "Hands-on culinary program focusing on cooking techniques, food safety, and kitchen management.",
          requirements: ["10+2 completion", "Physical fitness", "Creativity assessment"],
          highlights: ["Professional kitchen training", "Celebrity chef workshops", "Restaurant placements"],
          image: "https://images.pexels.com/photos/735869/pexels-photo-735869.jpeg?auto=compress&cs=tinysrgb&w=400"
        },
        {
          title: "Diploma in Food & Beverage Service",
          duration: "6 Months",
          fee: "₹80,000",
          description: "Specialized program in restaurant service, beverage management, and customer relations.",
          requirements: ["12th pass", "Good communication skills", "Service aptitude"],
          highlights: ["Live restaurant training", "Beverage certification", "5-star hotel placements"],
          image: "https://images.pexels.com/photos/1267320/pexels-photo-1267320.jpeg?auto=compress&cs=tinysrgb&w=400"
        }
      ]
    },
    certificates: {
      title: "Short-term Certificates",
      icon: <ChefHat className="text-accent" size={24} />,
      courses: [
        {
          title: "Professional Housekeeping",
          duration: "3 Months",
          fee: "₹25,000",
          description: "Comprehensive training in hotel housekeeping operations, cleaning techniques, and guest services.",
          requirements: ["Basic education", "Physical fitness", "Attention to detail"],
          highlights: ["Industry certification", "Immediate job placement", "Flexible timings"],
          image: "https://images.pexels.com/photos/271897/pexels-photo-271897.jpeg?auto=compress&cs=tinysrgb&w=400"
        },
        {
          title: "Front Office Operations",
          duration: "2 Months",
          fee: "₹20,000",
          description: "Essential skills for front desk operations, reservation systems, and guest relations.",
          requirements: ["Good communication", "Computer literacy", "Professional attitude"],
          highlights: ["Hotel software training", "Customer service excellence", "Career advancement"],
          image: "https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg?auto=compress&cs=tinysrgb&w=400"
        },
        {
          title: "Barista & Coffee Skills",
          duration: "1 Month",
          fee: "₹15,000",
          description: "Professional coffee preparation techniques and cafe management skills.",
          requirements: ["Basic English", "Interest in coffee culture", "Manual dexterity"],
          highlights: ["International certification", "Cafe partnerships", "Entrepreneurship support"],
          image: "https://images.pexels.com/photos/302899/pexels-photo-302899.jpeg?auto=compress&cs=tinysrgb&w=400"
        }
      ]
    }
  };

  const handleCardFlip = (index: number) => {
    setFlippedCard(flippedCard === index ? null : index);
  };

  return (
    <div className="min-h-screen pt-32">
      <div className="container mx-auto px-4 py-12">
        {/* Header Section */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">Our Courses</h1>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            Choose from our comprehensive range of hospitality programs designed to prepare you for a successful career in the industry
          </p>
        </div>

        {/* Category Tabs */}
        <div className="flex flex-wrap justify-center mb-16">
          <div className="bg-light-gray rounded-xl p-2 inline-flex">
            {Object.entries(courseCategories).map(([key, category]) => (
              <button
                key={key}
                onClick={() => setActiveTab(key)}
                className={`flex items-center space-x-2 px-6 py-3 rounded-lg transition-all duration-300 font-medium ${
                  activeTab === key
                    ? 'bg-accent text-white shadow-lg transform scale-105'
                    : 'text-gray-600 hover:text-accent hover:bg-white'
                }`}
              >
                {category.icon}
                <span>{category.title}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Course Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {courseCategories[activeTab as keyof typeof courseCategories].courses.map((course, index) => (
            <div
              key={index}
              className="relative h-[500px] cursor-pointer group"
              onClick={() => handleCardFlip(index)}
            >
              {/* Card Container with 3D Transform */}
              <div className={`absolute inset-0 w-full h-full transition-transform duration-700 transform-style-preserve-3d ${
                flippedCard === index ? 'rotate-y-180' : ''
              }`}>
                
                {/* Front Side */}
                <div className="absolute inset-0 w-full h-full backface-hidden rounded-xl overflow-hidden shadow-lg bg-white">
                  <div className="relative">
                    <img
                      src={course.image}
                      alt={course.title}
                      className="w-full h-56 object-cover"
                    />
                    <div className="absolute top-4 right-4 bg-accent text-white px-3 py-1 rounded-full text-sm font-semibold">
                      {course.fee}
                    </div>
                    <div className="absolute bottom-4 left-4 bg-black bg-opacity-50 text-white px-3 py-1 rounded-full text-sm">
                      {course.duration}
                    </div>
                  </div>
                  
                  <div className="p-6">
                    <h3 className="text-xl font-bold mb-3 text-primary">{course.title}</h3>
                    <div className="flex items-center space-x-4 mb-4 text-sm text-gray-600">
                      <div className="flex items-center space-x-1">
                        <Clock size={16} className="text-accent" />
                        <span>{course.duration}</span>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Award size={16} className="text-accent" />
                        <span>{course.fee}</span>
                      </div>
                    </div>
                    <p className="text-gray-600 text-sm mb-6 leading-relaxed line-clamp-3">
                      {course.description}
                    </p>
                    <div className="text-center">
                      <div className="inline-flex items-center text-accent font-medium text-sm hover:text-primary transition-colors">
                        <span>Click to see details</span>
                        <ArrowRight size={16} className="ml-1" />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Back Side */}
                <div className="absolute inset-0 w-full h-full backface-hidden rotate-y-180 rounded-xl bg-gradient-to-br from-primary to-secondary text-white p-6 flex flex-col justify-between shadow-lg">
                  <div>
                    <h3 className="text-xl font-bold mb-6 text-center">{course.title}</h3>
                    
                    <div className="mb-6">
                      <h4 className="font-semibold mb-3 text-accent flex items-center">
                        <CheckCircle size={16} className="mr-2" />
                        Requirements:
                      </h4>
                      <ul className="text-sm space-y-2">
                        {course.requirements.map((req, i) => (
                          <li key={i} className="flex items-start space-x-2">
                            <div className="w-1.5 h-1.5 bg-accent rounded-full mt-2 flex-shrink-0"></div>
                            <span className="leading-relaxed">{req}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="mb-6">
                      <h4 className="font-semibold mb-3 text-accent flex items-center">
                        <Award size={16} className="mr-2" />
                        Highlights:
                      </h4>
                      <ul className="text-sm space-y-2">
                        {course.highlights.map((highlight, i) => (
                          <li key={i} className="flex items-start space-x-2">
                            <div className="w-1.5 h-1.5 bg-accent rounded-full mt-2 flex-shrink-0"></div>
                            <span className="leading-relaxed">{highlight}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <a 
                      href="/contact" 
                      className="block w-full bg-accent hover:bg-yellow-600 text-white text-center py-3 rounded-lg font-semibold transition-colors"
                      onClick={(e) => e.stopPropagation()}
                    >
                      Apply Now
                    </a>
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        handleCardFlip(index);
                      }}
                      className="w-full text-center text-accent text-sm font-medium hover:text-white transition-colors"
                    >
                      ← Back to overview
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Call to Action Section */}
        <div className="text-center">
          <div className="bg-gradient-to-r from-primary to-secondary text-white rounded-2xl p-8 md:p-12 shadow-2xl">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Start Your Journey?</h2>
            <p className="text-lg md:text-xl mb-8 max-w-2xl mx-auto leading-relaxed opacity-90">
              Join thousands of successful graduates who have built rewarding careers in hospitality
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <a 
                href="/contact" 
                className="inline-flex items-center justify-center px-8 py-4 bg-accent hover:bg-yellow-600 text-white font-semibold rounded-lg transition-all duration-300 transform hover:scale-105"
              >
                Apply Now
                <ArrowRight size={20} className="ml-2" />
              </a>
              <a 
                href="/about" 
                className="inline-flex items-center justify-center px-8 py-4 bg-white text-primary hover:bg-gray-100 font-semibold rounded-lg transition-all duration-300"
              >
                Learn More About Us
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Courses;