import React, { useState, useEffect } from 'react';
import { useInView } from 'react-intersection-observer';
import { ChefHat, Users, Award, BookOpen, Star, Quote, ArrowRight } from 'lucide-react';

const Home: React.FC = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [ref, inView] = useInView({ triggerOnce: true, threshold: 0.1 });

  const heroImages = [
    'https://images.pexels.com/photos/260922/pexels-photo-260922.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080&fit=crop',
    'https://images.pexels.com/photos/1449773/pexels-photo-1449773.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080&fit=crop',
    'https://images.pexels.com/photos/735869/pexels-photo-735869.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080&fit=crop'
  ];

  const testimonials = [
    {
      name: "Sarah Johnson",
      role: "Hotel Manager, Marriott",
      content: "The practical training and industry exposure at Empee Institute prepared me perfectly for my career in hospitality management.",
      rating: 5,
      image: "https://images.pexels.com/photos/3778876/pexels-photo-3778876.jpeg?auto=compress&cs=tinysrgb&w=300"
    },
    {
      name: "Michael Chen",
      role: "Executive Chef, Hilton",
      content: "The culinary program here is exceptional. The hands-on experience and mentorship from industry professionals is invaluable.",
      rating: 5,
      image: "https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=300"
    },
    {
      name: "Priya Sharma",
      role: "Event Coordinator, Taj Hotels",
      content: "The comprehensive curriculum and career placement support helped me secure my dream job in the hospitality industry.",
      rating: 5,
      image: "https://images.pexels.com/photos/1181519/pexels-photo-1181519.jpeg?auto=compress&cs=tinysrgb&w=300"
    }
  ];

  const partners = [
    { name: "Marriott International", logo: "🏨", color: "#8B0000" },
    { name: "Hilton Hotels", logo: "🏢", color: "#0066CC" },
    { name: "Taj Hotels", logo: "🏛️", color: "#DAA520" },
    { name: "ITC Hotels", logo: "🏨", color: "#8B4513" },
    { name: "Oberoi Group", logo: "👑", color: "#FFD700" },
    { name: "Hyatt Hotels", logo: "🏨", color: "#000080" },
    { name: "Radisson Hotels", logo: "🏢", color: "#FF6B35" },
    { name: "AccorHotels", logo: "🏨", color: "#E31837" },
    { name: "Four Seasons", logo: "🌟", color: "#2E8B57" },
    { name: "Ritz Carlton", logo: "👑", color: "#B8860B" },
    { name: "Sheraton Hotels", logo: "🏢", color: "#4169E1" },
    { name: "Holiday Inn", logo: "🏨", color: "#228B22" }
  ];

  const stats = [
    { number: "5000+", label: "Graduates", icon: <Users className="text-accent" size={32} /> },
    { number: "95%", label: "Placement Rate", icon: <Award className="text-accent" size={32} /> },
    { number: "200+", label: "Industry Partners", icon: <BookOpen className="text-accent" size={32} /> },
    { number: "24", label: "Years of Excellence", icon: <Star className="text-accent" size={32} /> }
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroImages.length);
    }, 5000);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        {heroImages.map((image, index) => (
          <div
            key={index}
            className={`absolute inset-0 transition-opacity duration-1000 ${
              index === currentSlide ? 'opacity-100' : 'opacity-0'
            }`}
          >
            <img
              src={image}
              alt={`Hero ${index + 1}`}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-black bg-opacity-50"></div>
          </div>
        ))}
        
        <div className="relative z-10 text-center text-white px-4 max-w-4xl mx-auto">
          <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
            Excellence in<br />
            <span className="text-accent">Hospitality Education</span>
          </h1>
          <p className="text-xl md:text-2xl mb-8 leading-relaxed">
            Shape your future in the hospitality industry with world-class training and industry exposure
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a href="/courses" className="btn btn-primary inline-flex items-center gap-2">
              Explore Courses <ArrowRight size={20} />
            </a>
            <a href="/contact" className="btn btn-secondary text-white border-white hover:bg-white hover:text-primary">
              Contact Us
            </a>
          </div>
        </div>

        {/* Slide Indicators */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex space-x-2">
          {heroImages.map((_, index) => (
            <button
              key={index}
              className={`w-3 h-3 rounded-full transition-all ${
                index === currentSlide ? 'bg-accent' : 'bg-white bg-opacity-50'
              }`}
              onClick={() => setCurrentSlide(index)}
            />
          ))}
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-primary text-white">
        <div className="container">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8" ref={ref}>
            {stats.map((stat, index) => (
              <div key={index} className={`text-center fade-in ${inView ? 'visible' : ''}`} style={{ animationDelay: `${index * 0.2}s` }}>
                <div className="flex justify-center mb-4">
                  {stat.icon}
                </div>
                <div className="text-3xl md:text-4xl font-bold text-accent mb-2">{stat.number}</div>
                <div className="text-gray-300">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="section bg-light-gray">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold mb-6">Welcome to Empee Institute</h2>
              <h3 className="text-xl font-semibold mb-4 text-accent">Shaping Future Hospitality Leaders</h3>
              <p className="text-gray-600 mb-6 leading-relaxed">
                For over two decades, Empee Institute of Hotel Management has been at the forefront of hospitality education, 
                providing comprehensive training programs that prepare students for successful careers in the dynamic 
                hospitality industry.
              </p>
              <p className="text-gray-600 mb-8 leading-relaxed">
                Our state-of-the-art facilities, experienced faculty, and strong industry partnerships ensure that our 
                graduates are well-equipped to meet the challenges of modern hospitality management.
              </p>
              <a href="/about" className="btn btn-primary inline-flex items-center gap-2">
                Learn More About Us <ArrowRight size={20} />
              </a>
            </div>
            <div className="relative">
              <img
                src="https://images.pexels.com/photos/374006/pexels-photo-374006.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Institute Building"
                className="rounded-lg shadow-lg w-full"
              />
              <div className="absolute -bottom-6 -right-6 bg-accent text-white p-6 rounded-lg shadow-lg">
                <div className="text-2xl font-bold">24+</div>
                <div className="text-sm">Years of Excellence</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Courses */}
      <section className="section">
        <div className="container">
          <h2 className="section-title">Featured Courses</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                title: "Hotel Management",
                duration: "3 Years",
                fee: "₹2,50,000",
                icon: <Users className="text-accent" size={40} />,
                description: "Comprehensive program covering all aspects of hotel operations and management.",
                image: "https://images.pexels.com/photos/941861/pexels-photo-941861.jpeg?auto=compress&cs=tinysrgb&w=400"
              },
              {
                title: "Culinary Arts",
                duration: "2 Years",
                fee: "₹1,50,000",
                icon: <ChefHat className="text-accent" size={40} />,
                description: "Master the art of cooking with hands-on training from professional chefs.",
                image: "https://images.pexels.com/photos/735869/pexels-photo-735869.jpeg?auto=compress&cs=tinysrgb&w=400"
              },
              {
                title: "Event Management",
                duration: "1 Year",
                fee: "₹1,20,000",
                icon: <Award className="text-accent" size={40} />,
                description: "Learn to plan, organize, and execute successful events and conferences.",
                image: "https://images.pexels.com/photos/1267320/pexels-photo-1267320.jpeg?auto=compress&cs=tinysrgb&w=400"
              }
            ].map((course, index) => (
              <div key={index} className="card overflow-hidden group cursor-pointer">
                <div className="relative overflow-hidden">
                  <img
                    src={course.image}
                    alt={course.title}
                    className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute top-4 right-4 bg-accent text-white px-3 py-1 rounded-full text-sm font-medium">
                    {course.fee}
                  </div>
                </div>
                <div className="p-6">
                  <div className="flex items-center gap-3 mb-4">
                    {course.icon}
                    <div>
                      <h3 className="text-xl font-semibold">{course.title}</h3>
                      <p className="text-accent font-medium">{course.duration}</p>
                    </div>
                  </div>
                  <p className="text-gray-600 mb-4 leading-relaxed">{course.description}</p>
                  <a href="/courses" className="btn btn-primary w-full text-center">
                    Learn More
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="section bg-light-gray">
        <div className="container">
          <h2 className="section-title">What Our Students Say</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="card p-6 text-center">
                <div className="flex justify-center mb-4">
                  <img
                    src={testimonial.image}
                    alt={testimonial.name}
                    className="w-16 h-16 rounded-full object-cover"
                  />
                </div>
                <div className="flex justify-center mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="text-yellow-400 fill-current" size={20} />
                  ))}
                </div>
                <p className="text-gray-600 mb-4 italic leading-relaxed">"{testimonial.content}"</p>
                <div>
                  <h4 className="font-semibold">{testimonial.name}</h4>
                  <p className="text-sm text-gray-500">{testimonial.role}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Industry Partners - Scrolling Section */}
      <section className="section">
        <div className="container">
          <h2 className="section-title">Our Industry Partners</h2>
          <p className="text-center text-gray-600 mb-12 max-w-3xl mx-auto">
            We collaborate with leading hospitality brands worldwide to provide our students with real-world experience 
            and excellent career opportunities.
          </p>
          
          <div className="partners-scroll">
            <div className="partners-track">
              {/* First set of partners */}
              {partners.map((partner, index) => (
                <div key={index} className="partner-item">
                  <div className="partner-logo" style={{ color: partner.color }}>
                    {partner.logo}
                  </div>
                  <div className="partner-name">{partner.name}</div>
                </div>
              ))}
              {/* Duplicate set for seamless scrolling */}
              {partners.map((partner, index) => (
                <div key={`duplicate-${index}`} className="partner-item">
                  <div className="partner-logo" style={{ color: partner.color }}>
                    {partner.logo}
                  </div>
                  <div className="partner-name">{partner.name}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-20 bg-gradient-to-r from-primary to-secondary text-white">
        <div className="container text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">Ready to Start Your Journey?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto leading-relaxed">
            Join thousands of successful graduates who have built rewarding careers in hospitality
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a href="/courses" className="btn btn-primary">
              Explore Courses
            </a>
            <a href="/contact" className="btn btn-secondary bg-white text-primary hover:bg-gray-100">
              Get in Touch
            </a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;